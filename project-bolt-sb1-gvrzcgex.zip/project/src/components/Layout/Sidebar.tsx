import React from 'react';
import { NavLink } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { 
  Home, 
  Music, 
  Upload, 
  TrendingUp, 
  Users, 
  Settings, 
  LogOut,
  User,
  FileText,
  DollarSign
} from 'lucide-react';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, onClose }) => {
  const { user, logout } = useAuth();

  const artistNavItems = [
    { to: '/dashboard', icon: Home, label: 'Ana Sayfa' },
    { to: '/submit', icon: Upload, label: 'Şarkı Gönder' },
    { to: '/catalog', icon: Music, label: 'Katalog' },
    { to: '/financials', icon: TrendingUp, label: 'Gelir Verileri' },
    { to: '/artists', icon: User, label: 'Sanatçılar' }
  ];

  const adminNavItems = [
    { to: '/admin/dashboard', icon: Home, label: 'Ana Sayfa' },
    { to: '/admin/users', icon: Users, label: 'Kullanıcılar' },
    { to: '/admin/songs', icon: FileText, label: 'Şarkı İncelemesi' },
    { to: '/admin/finance', icon: DollarSign, label: 'Finans Paneli' }
  ];

  const navItems = user?.role === 'admin' ? adminNavItems : artistNavItems;

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={onClose}
        />
      )}
      
      {/* Sidebar */}
      <div className={`fixed top-0 left-0 h-full w-64 bg-white shadow-xl transform transition-transform duration-300 ease-in-out z-50 ${
        isOpen ? 'translate-x-0' : '-translate-x-full'
      } lg:translate-x-0 lg:static lg:z-auto`}>
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-blue-500 rounded-lg flex items-center justify-center">
              <Music className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900">Scarp Music</h1>
              <p className="text-sm text-gray-500">{user?.role === 'admin' ? 'Admin Panel' : 'Sanatçı Paneli'}</p>
            </div>
          </div>
        </div>

        <nav className="flex-1 p-4 space-y-2">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              onClick={onClose}
              className={({ isActive }) => 
                `flex items-center space-x-3 p-3 rounded-lg transition-colors ${
                  isActive 
                    ? 'bg-gradient-to-r from-purple-500 to-blue-500 text-white' 
                    : 'text-gray-700 hover:bg-gray-100'
                }`
              }
            >
              <item.icon className="w-5 h-5" />
              <span className="font-medium">{item.label}</span>
            </NavLink>
          ))}
        </nav>

        <div className="p-4 border-t border-gray-200">
          <button
            onClick={logout}
            className="flex items-center space-x-3 w-full p-3 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
          >
            <LogOut className="w-5 h-5" />
            <span className="font-medium">Çıkış Yap</span>
          </button>
        </div>
      </div>
    </>
  );
};

export default Sidebar;