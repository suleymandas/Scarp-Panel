import React from 'react';
import { AlertTriangle, Mail } from 'lucide-react';

const WarningPanel: React.FC = () => {
  return (
    <div className="bg-gradient-to-r from-orange-50 to-red-50 border border-orange-200 rounded-xl p-6">
      <div className="flex items-start space-x-3">
        <div className="flex-shrink-0">
          <AlertTriangle className="w-6 h-6 text-orange-600" />
        </div>
        <div className="flex-1">
          <h3 className="text-lg font-semibold text-orange-900 mb-3">
            ⚠️ DİKKAT: Yayın Öncesi Bilgilendirme
          </h3>
          
          <div className="space-y-3 text-sm text-orange-800">
            <div className="flex items-start space-x-2">
              <span className="text-orange-600 font-bold">📌</span>
              <p>Paket limitinize ulaştığınızda ek sanatçı eklemek için temsilcinizle iletişime geçin.</p>
            </div>
            
            <div className="flex items-start space-x-2">
              <span className="text-orange-600 font-bold">📌</span>
              <p>PR (basın, reklam, playlist vs.) işlemleri için temsilcinizle iletişime geçin.</p>
            </div>
            
            <div className="flex items-start space-x-2">
              <span className="text-orange-600 font-bold">📌</span>
              <p>Yayın düzenleme veya kaldırma talebiniz varsa, lütfen temsilcinizle iletişime geçin.</p>
            </div>
            
            <div className="flex items-start space-x-2">
              <span className="text-orange-600 font-bold">📌</span>
              <div>
                <p className="font-medium mb-1">Remix / Mix / Cover parçaları için:</p>
                <ul className="ml-4 space-y-1">
                  <li>• Şarkıyı sisteme gönderdikten sonra temsilcinizle iletişime geçip izin belgesi paylaşmanız zorunludur.</li>
                  <li>• Eğer izinsiz yayın yaparsanız hesabınız askıya alınabilir.</li>
                </ul>
              </div>
            </div>
          </div>
          
          <div className="mt-6 pt-4 border-t border-orange-200">
            <h4 className="font-medium text-orange-900 mb-3">Temsilcinizle İletişim:</h4>
            <div className="flex flex-wrap gap-3">
              <a
                href="mailto:scarpdistro@gmail.com"
                className="inline-flex items-center space-x-2 px-4 py-2 bg-orange-100 hover:bg-orange-200 text-orange-800 rounded-lg transition-colors"
              >
                <Mail className="w-4 h-4" />
                <span>E-posta Gönder</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WarningPanel;