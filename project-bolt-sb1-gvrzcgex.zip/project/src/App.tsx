import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { SongProvider } from './contexts/SongContext';
import { NotificationProvider } from './contexts/NotificationContext';
import Layout from './components/Layout/Layout';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import SubmitSong from './pages/SubmitSong';
import Catalog from './pages/Catalog';
import Financials from './pages/Financials';
import Artists from './pages/Artists';
import AdminDashboard from './pages/AdminDashboard';
import AdminUsers from './pages/AdminUsers';
import AdminSongs from './pages/AdminSongs';
import AdminFinance from './pages/AdminFinance';

const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-purple-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Yükleniyor...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  return <>{children}</>;
};

const AppRoutes: React.FC = () => {
  const { user } = useAuth();

  if (!user) {
    return (
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    );
  }

  return (
    <Layout>
      <Routes>
        {user.role === 'artist' ? (
          <>
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/submit" element={<SubmitSong />} />
            <Route path="/catalog" element={<Catalog />} />
            <Route path="/financials" element={<Financials />} />
            <Route path="/artists" element={<Artists />} />
            <Route path="/" element={<Navigate to="/dashboard" replace />} />
          </>
        ) : (
          <>
            <Route path="/admin/dashboard" element={<AdminDashboard />} />
            <Route path="/admin/users" element={<AdminUsers />} />
            <Route path="/admin/songs" element={<AdminSongs />} />
            <Route path="/admin/finance" element={<AdminFinance />} />
            <Route path="/" element={<Navigate to="/admin/dashboard" replace />} />
          </>
        )}
        <Route path="*" element={<Navigate to={user.role === 'artist' ? '/dashboard' : '/admin/dashboard'} replace />} />
      </Routes>
    </Layout>
  );
};

function App() {
  return (
    <AuthProvider>
      <SongProvider>
        <NotificationProvider>
          <Router>
            <div className="App">
              <AppRoutes />
            </div>
          </Router>
        </NotificationProvider>
      </SongProvider>
    </AuthProvider>
  );
}

export default App;