export interface User {
  id: string;
  username: string;
  role: 'artist' | 'admin';
  package: 'starter' | 'pro' | 'unlimited';
  artistCount: number;
  totalSongs: number;
  totalEarnings: number;
}

export interface Artist {
  id: string;
  name: string;
  spotifyLink: string;
  appleMusicLink: string;
  userId: string;
}

export interface Song {
  id: string;
  releaseCode: string; // Benzersiz yayın kodu
  releaseType: 'single' | 'ep' | 'album' | 'composition';
  albumCover: string;
  primaryArtists: Artist[];
  featuredArtists: Artist[];
  upcCode: string;
  albumName: string;
  albumType: string;
  albumLanguage: string;
  releaseStatus: 'previously_released' | 'new_release';
  originalReleaseDate?: string;
  newReleaseDate?: string;
  tracks: Track[];
  status: 'review' | 'approved' | 'distributed';
  userId: string;
  submittedAt: string;
}

export interface Track {
  id: string;
  fileLink: string;
  trackName: string;
  isrcCode: string;
  hasExplicitContent: boolean;
  youtubeContentId: boolean;
  primaryArtists: Artist[];
  featuredArtists: Artist[];
  songwriter: string;
  composer: string;
  language: string;
  genre: string;
}

export interface FinancialData {
  id: string;
  userId: string;
  month: string;
  spotifyRevenue: number;
  appleMusicRevenue: number;
  youtubeMusicRevenue: number;
  otherRevenue: number;
  totalRevenue: number;
}

export const PACKAGE_LIMITS = {
  starter: 1,
  pro: 3,
  unlimited: 999
};

// Yayın kodu oluşturma fonksiyonu
export const generateReleaseCode = (): string => {
  const year = new Date().getFullYear();
  const randomNum = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
  return `SCR${year}${randomNum}`;
};