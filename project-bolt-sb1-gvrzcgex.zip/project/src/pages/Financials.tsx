import React, { useState } from 'react';
import { TrendingUp, DollarSign, Calendar, CreditCard, AlertCircle, CheckCircle } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

interface MonthlyRevenue {
  month: string;
  spotify: number;
  appleMusic: number;
  youtubeMusic: number;
  other: number;
  total: number;
}

interface WithdrawalRequest {
  id: string;
  amount: number;
  requestDate: string;
  status: 'pending' | 'approved' | 'completed';
  bankInfo: string;
}

const Financials: React.FC = () => {
  const { user } = useAuth();
  const [selectedPeriod, setSelectedPeriod] = useState('all');
  const [showWithdrawalForm, setShowWithdrawalForm] = useState(false);
  const [withdrawalAmount, setWithdrawalAmount] = useState('');
  const [bankInfo, setBankInfo] = useState('');

  if (!user) return null;

  // Load user-specific financial data
  const financialData: MonthlyRevenue[] = (() => {
    const savedData = localStorage.getItem(`financials_${user.id}`);
    return savedData ? JSON.parse(savedData) : [];
  })();

  const withdrawals: WithdrawalRequest[] = (() => {
    const savedWithdrawals = localStorage.getItem(`withdrawals_${user.id}`);
    return savedWithdrawals ? JSON.parse(savedWithdrawals) : [];
  })();

  const totalRevenue = financialData.reduce((sum, month) => sum + month.total, 0);
  const totalWithdrawn = withdrawals.reduce((sum, withdrawal) => 
    withdrawal.status === 'completed' ? sum + withdrawal.amount : sum, 0
  );
  const pendingWithdrawals = withdrawals.reduce((sum, withdrawal) => 
    withdrawal.status === 'pending' ? sum + withdrawal.amount : sum, 0
  );
  const availableBalance = totalRevenue - totalWithdrawn - pendingWithdrawals;
  const avgMonthlyRevenue = financialData.length > 0 ? totalRevenue / financialData.length : 0;
  const canWithdraw = availableBalance >= 750;

  const formatCurrency = (amount: number) => {
    return `₺${amount.toLocaleString('tr-TR', { minimumFractionDigits: 2 })}`;
  };

  const formatMonth = (monthStr: string) => {
    const [year, month] = monthStr.split('-');
    const date = new Date(parseInt(year), parseInt(month) - 1);
    return date.toLocaleDateString('tr-TR', { month: 'long', year: 'numeric' });
  };

  const getMaxRevenue = () => {
    return financialData.length > 0 ? Math.max(...financialData.map(data => data.total)) : 0;
  };

  const handleWithdrawalRequest = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(withdrawalAmount);
    
    if (amount < 750) {
      alert('Minimum çekim tutarı 750 TL\'dir.');
      return;
    }
    
    if (amount > availableBalance) {
      alert('Yetersiz bakiye. Mevcut bakiyeniz: ' + formatCurrency(availableBalance));
      return;
    }

    // Here you would normally send the request to your backend
    alert(`${formatCurrency(amount)} tutarında çekim talebiniz alındı. İşlem 3-5 iş günü içinde hesabınıza yansıyacaktır.`);
    setShowWithdrawalForm(false);
    setWithdrawalAmount('');
    setBankInfo('');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'pending':
        return 'bg-orange-100 text-orange-800';
      case 'approved':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'completed':
        return 'Tamamlandı';
      case 'pending':
        return 'Beklemede';
      case 'approved':
        return 'Onaylandı';
      default:
        return 'Bilinmiyor';
    }
  };

  const maxRevenue = getMaxRevenue();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-green-600 to-blue-600 rounded-2xl text-white p-8">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
            <TrendingUp className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-3xl font-bold">Gelir Verileri</h1>
            <p className="text-green-100 mt-1">Platformlardan elde ettiğiniz gelirleri takip edin</p>
          </div>
        </div>
      </div>

      {/* Balance and Withdrawal Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Balance Cards */}
        <div className="lg:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Toplam Gelir</p>
                <p className="text-2xl font-bold text-gray-900">{formatCurrency(totalRevenue)}</p>
              </div>
              <DollarSign className="w-8 h-8 text-green-500" />
            </div>
          </div>

          <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Çekilen Tutar</p>
                <p className="text-2xl font-bold text-gray-900">{formatCurrency(totalWithdrawn)}</p>
              </div>
              <CreditCard className="w-8 h-8 text-blue-500" />
            </div>
          </div>

          <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Bekleyen Çekim</p>
                <p className="text-2xl font-bold text-orange-600">{formatCurrency(pendingWithdrawals)}</p>
              </div>
              <Calendar className="w-8 h-8 text-orange-500" />
            </div>
          </div>

          <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Çekilebilir Bakiye</p>
                <p className={`text-2xl font-bold ${canWithdraw ? 'text-green-600' : 'text-red-600'}`}>
                  {formatCurrency(availableBalance)}
                </p>
              </div>
              <TrendingUp className={`w-8 h-8 ${canWithdraw ? 'text-green-500' : 'text-red-500'}`} />
            </div>
          </div>
        </div>

        {/* Withdrawal Panel */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
          <div className="flex items-center space-x-3 mb-4">
            <CreditCard className="w-6 h-6 text-purple-600" />
            <h3 className="text-lg font-semibold text-gray-900">Para Çekme</h3>
          </div>

          {canWithdraw ? (
            <div>
              <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-4">
                <div className="flex items-start space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-green-800">Çekim Yapabilirsiniz</p>
                    <p className="text-xs text-green-700 mt-1">
                      Mevcut bakiyeniz: {formatCurrency(availableBalance)}
                    </p>
                  </div>
                </div>
              </div>

              {!showWithdrawalForm ? (
                <button
                  onClick={() => setShowWithdrawalForm(true)}
                  className="w-full bg-gradient-to-r from-green-500 to-blue-500 text-white font-semibold py-3 px-4 rounded-lg hover:from-green-600 hover:to-blue-600 transition-all"
                >
                  Para Çek
                </button>
              ) : (
                <form onSubmit={handleWithdrawalRequest} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Çekim Tutarı (Min. 750 TL)
                    </label>
                    <input
                      type="number"
                      min="750"
                      max={availableBalance}
                      step="0.01"
                      value={withdrawalAmount}
                      onChange={(e) => setWithdrawalAmount(e.target.value)}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                      placeholder="750.00"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Banka Bilgileri
                    </label>
                    <textarea
                      value={bankInfo}
                      onChange={(e) => setBankInfo(e.target.value)}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                      rows={3}
                      placeholder="Banka adı, IBAN, hesap sahibi adı"
                      required
                    />
                  </div>

                  <div className="flex space-x-3">
                    <button
                      type="submit"
                      className="flex-1 bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition-colors"
                    >
                      Talep Gönder
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowWithdrawalForm(false)}
                      className="flex-1 bg-gray-300 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-400 transition-colors"
                    >
                      İptal
                    </button>
                  </div>
                </form>
              )}
            </div>
          ) : (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <div className="flex items-start space-x-2">
                <AlertCircle className="w-5 h-5 text-red-600 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-red-800">Çekim Yapılamaz</p>
                  <p className="text-xs text-red-700 mt-1">
                    Minimum 750 TL bakiye gerekli. Mevcut: {formatCurrency(availableBalance)}
                  </p>
                  {availableBalance < 750 && (
                    <p className="text-xs text-red-700 mt-1">
                      Eksik: {formatCurrency(750 - availableBalance)}
                    </p>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* No Data Message */}
      {financialData.length === 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <TrendingUp className="w-8 h-8 text-gray-400" />
          </div>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">Henüz Gelir Verisi Yok</h3>
          <p className="text-gray-600 mb-6">
            Şarkılarınız dağıtıldıktan sonra gelir verileri burada görünecektir.
          </p>
          <a
            href="/submit"
            className="inline-flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-green-500 to-blue-500 text-white rounded-lg hover:from-green-600 hover:to-blue-600 transition-all"
          >
            <span>İlk Şarkınızı Gönderin</span>
          </a>
        </div>
      )}

      {/* Withdrawal History */}
      {withdrawals.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">Çekim Geçmişi</h2>
          
          <div className="space-y-4">
            {withdrawals.map((withdrawal) => (
              <div key={withdrawal.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-4">
                  <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                    <CreditCard className="w-5 h-5 text-purple-600" />
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">{formatCurrency(withdrawal.amount)}</p>
                    <p className="text-sm text-gray-600">{withdrawal.bankInfo}</p>
                    <p className="text-xs text-gray-500">
                      {new Date(withdrawal.requestDate).toLocaleDateString('tr-TR')}
                    </p>
                  </div>
                </div>
                <div className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(withdrawal.status)}`}>
                  {getStatusText(withdrawal.status)}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Summary Cards */}
      {financialData.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Aylık Ortalama</p>
                <p className="text-2xl font-bold text-gray-900">{formatCurrency(avgMonthlyRevenue)}</p>
              </div>
              <Calendar className="w-8 h-8 text-blue-500" />
            </div>
          </div>

          <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Son Ay</p>
                <p className="text-2xl font-bold text-gray-900">
                  {financialData.length > 0 
                    ? formatCurrency(financialData[financialData.length - 1].total)
                    : formatCurrency(0)
                  }
                </p>
              </div>
              <div className="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center">
                <span className="text-orange-600 font-bold">₺</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Withdrawal Information */}
      <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
        <div className="flex items-start space-x-3">
          <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
            <span className="text-white text-xs font-bold">ℹ</span>
          </div>
          <div>
            <h3 className="font-semibold text-blue-900 mb-2">Para Çekme Hakkında</h3>
            <ul className="text-sm text-blue-800 space-y-1 list-disc ml-4">
              <li>Minimum çekim tutarı 750 TL'dir.</li>
              <li>Çekim talepleri 3-5 iş günü içinde işleme alınır.</li>
              <li>Banka bilgilerinizi doğru ve eksiksiz girdiğinizden emin olun.</li>
              <li>Çekim işlemleri için herhangi bir komisyon alınmaz.</li>
              <li>Çekim geçmişinizi bu sayfadan takip edebilirsiniz.</li>
              <li>Gelir verileri şarkılarınızın dağıtım performansına göre güncellenir.</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Financials;