import React, { useState, useEffect } from 'react';
import { Users, Search, Filter, Eye, Edit, Trash2, Plus, Package, Calendar, DollarSign, Music, X, User } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

interface AdminUser {
  id: string;
  username: string;
  email: string;
  role: 'artist' | 'admin';
  package: 'starter' | 'pro' | 'unlimited';
  artistCount: number;
  totalSongs: number;
  totalEarnings: number;
  joinDate: string;
  lastLogin: string;
  status: 'active' | 'inactive' | 'suspended';
  artists: Array<{
    id: string;
    name: string;
    spotifyLink: string;
    appleMusicLink: string;
  }>;
}

const AdminUsers: React.FC = () => {
  const { addUser, getAllUsers } = useAuth();
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterPackage, setFilterPackage] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [selectedUser, setSelectedUser] = useState<AdminUser | null>(null);
  const [showUserModal, setShowUserModal] = useState(false);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showArtistsModal, setShowArtistsModal] = useState(false);
  const [selectedUserArtists, setSelectedUserArtists] = useState<any[]>([]);
  const [createForm, setCreateForm] = useState({
    username: '',
    email: '',
    role: 'artist' as 'artist' | 'admin',
    package: 'starter' as 'starter' | 'pro' | 'unlimited',
    password: ''
  });

  // Load users from AuthContext and their artists
  useEffect(() => {
    const allUsers = getAllUsers();
    const adminUsers: AdminUser[] = allUsers.map(user => {
      // Load user-specific artists from localStorage
      const savedArtists = localStorage.getItem(`artists_${user.id}`);
      const userArtists = savedArtists ? JSON.parse(savedArtists) : [];
      
      return {
        id: user.id,
        username: user.username,
        email: user.username + '@example.com', // Mock email
        role: user.role,
        package: user.package,
        artistCount: userArtists.length, // Real artist count
        totalSongs: user.totalSongs,
        totalEarnings: user.totalEarnings,
        joinDate: '2024-01-15', // Mock date
        lastLogin: '2024-04-10', // Mock date
        status: 'active' as const,
        artists: userArtists
      };
    });
    setUsers(adminUsers);
  }, [getAllUsers]);

  const filteredUsers = users.filter(user => {
    const matchesSearch = user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         user.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesPackage = filterPackage === 'all' || user.package === filterPackage;
    const matchesStatus = filterStatus === 'all' || user.status === filterStatus;
    
    return matchesSearch && matchesPackage && matchesStatus;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800';
      case 'inactive':
        return 'bg-gray-100 text-gray-800';
      case 'suspended':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'active':
        return 'Aktif';
      case 'inactive':
        return 'Pasif';
      case 'suspended':
        return 'Askıda';
      default:
        return 'Bilinmiyor';
    }
  };

  const getPackageColor = (pkg: string) => {
    switch (pkg) {
      case 'starter':
        return 'bg-blue-100 text-blue-800';
      case 'pro':
        return 'bg-purple-100 text-purple-800';
      case 'unlimited':
        return 'bg-gradient-to-r from-yellow-100 to-orange-100 text-orange-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getPackageText = (pkg: string) => {
    switch (pkg) {
      case 'starter':
        return 'Starter';
      case 'pro':
        return 'Pro';
      case 'unlimited':
        return 'Unlimited';
      default:
        return 'Bilinmiyor';
    }
  };

  const handleUserAction = (action: string, userId: string) => {
    switch (action) {
      case 'suspend':
        setUsers(users.map(user => 
          user.id === userId ? { ...user, status: 'suspended' } : user
        ));
        break;
      case 'activate':
        setUsers(users.map(user => 
          user.id === userId ? { ...user, status: 'active' } : user
        ));
        break;
      case 'delete':
        if (confirm('Bu kullanıcıyı silmek istediğinizden emin misiniz?')) {
          setUsers(users.filter(user => user.id !== userId));
        }
        break;
    }
  };

  const handleCreateUser = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validation
    if (!createForm.username || !createForm.email || !createForm.password) {
      alert('Lütfen tüm gerekli alanları doldurun.');
      return;
    }

    // Check if username already exists
    const existingUser = users.find(user => user.username === createForm.username);
    if (existingUser) {
      alert('Bu kullanıcı adı zaten kullanılıyor.');
      return;
    }

    // Create new user for AuthContext
    const newUserForAuth = {
      id: Date.now().toString(),
      username: createForm.username,
      role: createForm.role,
      package: createForm.package,
      artistCount: 0,
      totalSongs: 0,
      totalEarnings: 0
    };

    // Add to AuthContext
    addUser(newUserForAuth, createForm.password);

    // Create new user for local state
    const newUser: AdminUser = {
      ...newUserForAuth,
      email: createForm.email,
      joinDate: new Date().toISOString().split('T')[0],
      lastLogin: new Date().toISOString().split('T')[0],
      status: 'active',
      artists: []
    };

    setUsers([...users, newUser]);
    
    // Reset form
    setCreateForm({
      username: '',
      email: '',
      role: 'artist',
      package: 'starter',
      password: ''
    });
    
    setShowCreateModal(false);
    alert('Kullanıcı başarıyla oluşturuldu! Giriş bilgileri: ' + createForm.username + ' / ' + createForm.password);
  };

  const handleViewArtists = (user: AdminUser) => {
    setSelectedUserArtists(user.artists);
    setSelectedUser(user);
    setShowArtistsModal(true);
  };

  const totalStats = {
    totalUsers: users.length,
    activeUsers: users.filter(u => u.status === 'active').length,
    totalRevenue: users.reduce((sum, user) => sum + user.totalEarnings, 0),
    totalSongs: users.reduce((sum, user) => sum + user.totalSongs, 0),
    totalArtists: users.reduce((sum, user) => sum + user.artists.length, 0)
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl text-white p-8">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-3xl font-bold">Kullanıcı Yönetimi</h1>
            <p className="text-blue-100 mt-1">Tüm kullanıcıları ve sanatçılarını görüntüleyin ve yönetin</p>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Toplam Kullanıcı</p>
              <p className="text-2xl font-bold text-gray-900">{totalStats.totalUsers}</p>
            </div>
            <Users className="w-8 h-8 text-blue-500" />
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Aktif Kullanıcı</p>
              <p className="text-2xl font-bold text-green-600">{totalStats.activeUsers}</p>
            </div>
            <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
              <div className="w-3 h-3 bg-green-500 rounded-full"></div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Toplam Sanatçı</p>
              <p className="text-2xl font-bold text-purple-600">{totalStats.totalArtists}</p>
            </div>
            <User className="w-8 h-8 text-purple-500" />
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Toplam Gelir</p>
              <p className="text-2xl font-bold text-gray-900">
                ₺{totalStats.totalRevenue.toLocaleString('tr-TR', { minimumFractionDigits: 2 })}
              </p>
            </div>
            <DollarSign className="w-8 h-8 text-green-500" />
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Toplam Şarkı</p>
              <p className="text-2xl font-bold text-gray-900">{totalStats.totalSongs}</p>
            </div>
            <Music className="w-8 h-8 text-purple-500" />
          </div>
        </div>
      </div>

      {/* Filters and Search */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
          <div className="flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Kullanıcı ara..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <select
              value={filterPackage}
              onChange={(e) => setFilterPackage(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="all">Tüm Paketler</option>
              <option value="starter">Starter</option>
              <option value="pro">Pro</option>
              <option value="unlimited">Unlimited</option>
            </select>

            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="all">Tüm Durumlar</option>
              <option value="active">Aktif</option>
              <option value="inactive">Pasif</option>
              <option value="suspended">Askıda</option>
            </select>
          </div>

          <button 
            onClick={() => setShowCreateModal(true)}
            className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Yeni Kullanıcı</span>
          </button>
        </div>
      </div>

      {/* Users Table */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">
            Kullanıcılar ({filteredUsers.length})
          </h2>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Kullanıcı
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Paket
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Sanatçı/Şarkı
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Gelir
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Durum
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Son Giriş
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  İşlemler
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredUsers.map((user) => (
                <tr key={user.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
                        <span className="text-white font-medium text-sm">
                          {user.username.charAt(0).toUpperCase()}
                        </span>
                      </div>
                      <div className="ml-4">
                        <div className="text-sm font-medium text-gray-900">{user.username}</div>
                        <div className="text-sm text-gray-500">{user.email}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getPackageColor(user.package)}`}>
                      {getPackageText(user.package)}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    <div className="flex items-center space-x-4">
                      <div className="text-center">
                        <div className="font-medium">{user.artists.length}</div>
                        <div className="text-xs text-gray-500">Sanatçı</div>
                      </div>
                      <div className="text-center">
                        <div className="font-medium">{user.totalSongs}</div>
                        <div className="text-xs text-gray-500">Şarkı</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    ₺{user.totalEarnings.toLocaleString('tr-TR', { minimumFractionDigits: 2 })}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(user.status)}`}>
                      {getStatusText(user.status)}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {new Date(user.lastLogin).toLocaleDateString('tr-TR')}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => {
                          setSelectedUser(user);
                          setShowUserModal(true);
                        }}
                        className="text-blue-600 hover:text-blue-900"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                      
                      {user.artists.length > 0 && (
                        <button
                          onClick={() => handleViewArtists(user)}
                          className="text-purple-600 hover:text-purple-900"
                          title="Sanatçıları Görüntüle"
                        >
                          <User className="w-4 h-4" />
                        </button>
                      )}
                      
                      <button className="text-gray-600 hover:text-gray-900">
                        <Edit className="w-4 h-4" />
                      </button>
                      {user.status === 'active' ? (
                        <button
                          onClick={() => handleUserAction('suspend', user.id)}
                          className="text-orange-600 hover:text-orange-900 text-xs"
                        >
                          Askıya Al
                        </button>
                      ) : (
                        <button
                          onClick={() => handleUserAction('activate', user.id)}
                          className="text-green-600 hover:text-green-900 text-xs"
                        >
                          Aktifleştir
                        </button>
                      )}
                      <button
                        onClick={() => handleUserAction('delete', user.id)}
                        className="text-red-600 hover:text-red-900"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Artists Modal */}
      {showArtistsModal && selectedUser && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 max-w-4xl w-full mx-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-semibold text-gray-900">
                {selectedUser.username} - Sanatçıları ({selectedUserArtists.length})
              </h3>
              <button
                onClick={() => setShowArtistsModal(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {selectedUserArtists.length === 0 ? (
              <div className="text-center py-12">
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <User className="w-8 h-8 text-gray-400" />
                </div>
                <p className="text-gray-600">Bu kullanıcının henüz sanatçısı yok</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {selectedUserArtists.map((artist, index) => (
                  <div key={artist.id} className="bg-gradient-to-r from-purple-50 to-blue-50 border border-purple-200 rounded-lg p-6">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-blue-500 rounded-lg flex items-center justify-center">
                        <User className="w-6 h-6 text-white" />
                      </div>
                      <div className="flex-1">
                        <h4 className="text-lg font-semibold text-gray-900">{artist.name}</h4>
                        <p className="text-sm text-gray-600">Birincil Sanatçı #{index + 1}</p>
                        
                        {/* Artist Links */}
                        {(artist.spotifyLink || artist.appleMusicLink) && (
                          <div className="flex space-x-2 mt-3">
                            {artist.spotifyLink && (
                              <a
                                href={artist.spotifyLink}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="inline-flex items-center space-x-1 px-3 py-1 bg-green-100 text-green-800 rounded-lg text-xs hover:bg-green-200 transition-colors"
                              >
                                <span>🎵</span>
                                <span>Spotify</span>
                              </a>
                            )}
                            {artist.appleMusicLink && (
                              <a
                                href={artist.appleMusicLink}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="inline-flex items-center space-x-1 px-3 py-1 bg-gray-100 text-gray-800 rounded-lg text-xs hover:bg-gray-200 transition-colors"
                              >
                                <span>🍎</span>
                                <span>Apple Music</span>
                              </a>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Create User Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 max-w-md w-full mx-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-semibold text-gray-900">Yeni Kullanıcı Oluştur</h3>
              <button
                onClick={() => setShowCreateModal(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateUser} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Kullanıcı Adı *
                </label>
                <input
                  type="text"
                  value={createForm.username}
                  onChange={(e) => setCreateForm({ ...createForm, username: e.target.value })}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="kullanici_adi"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  E-posta *
                </label>
                <input
                  type="email"
                  value={createForm.email}
                  onChange={(e) => setCreateForm({ ...createForm, email: e.target.value })}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="kullanici@example.com"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Şifre *
                </label>
                <input
                  type="password"
                  value={createForm.password}
                  onChange={(e) => setCreateForm({ ...createForm, password: e.target.value })}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Güçlü bir şifre girin"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Rol *
                </label>
                <select
                  value={createForm.role}
                  onChange={(e) => setCreateForm({ ...createForm, role: e.target.value as 'artist' | 'admin' })}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                >
                  <option value="artist">Sanatçı</option>
                  <option value="admin">Admin</option>
                </select>
              </div>

              {createForm.role === 'artist' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Paket *
                  </label>
                  <select
                    value={createForm.package}
                    onChange={(e) => setCreateForm({ ...createForm, package: e.target.value as 'starter' | 'pro' | 'unlimited' })}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  >
                    <option value="starter">Starter (1 sanatçı)</option>
                    <option value="pro">Pro (3 sanatçı)</option>
                    <option value="unlimited">Unlimited (Sınırsız)</option>
                  </select>
                </div>
              )}

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h4 className="font-medium text-blue-900 mb-2">Kullanıcı Bilgileri</h4>
                <ul className="text-sm text-blue-800 space-y-1">
                  <li>• Kullanıcı otomatik olarak aktif durumda oluşturulacak</li>
                  <li>• Giriş bilgileri kullanıcıya e-posta ile gönderilebilir</li>
                  <li>• Paket değişiklikleri sonradan yapılabilir</li>
                </ul>
              </div>

              <div className="flex space-x-4">
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 transition-colors font-medium"
                >
                  Kullanıcı Oluştur
                </button>
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="flex-1 bg-gray-300 text-gray-700 py-3 px-4 rounded-lg hover:bg-gray-400 transition-colors font-medium"
                >
                  İptal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* User Detail Modal */}
      {showUserModal && selectedUser && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 max-w-2xl w-full mx-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-semibold text-gray-900">Kullanıcı Detayları</h3>
              <button
                onClick={() => setShowUserModal(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Kullanıcı Adı</label>
                  <p className="text-gray-900">{selectedUser.username}</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">E-posta</label>
                  <p className="text-gray-900">{selectedUser.email}</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Paket</label>
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getPackageColor(selectedUser.package)}`}>
                    {getPackageText(selectedUser.package)}
                  </span>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Durum</label>
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(selectedUser.status)}`}>
                    {getStatusText(selectedUser.status)}
                  </span>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Sanatçı Sayısı</label>
                  <p className="text-gray-900">{selectedUser.artists.length}</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Toplam Şarkı</label>
                  <p className="text-gray-900">{selectedUser.totalSongs}</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Toplam Gelir</label>
                  <p className="text-gray-900">₺{selectedUser.totalEarnings.toLocaleString('tr-TR', { minimumFractionDigits: 2 })}</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Kayıt Tarihi</label>
                  <p className="text-gray-900">{new Date(selectedUser.joinDate).toLocaleDateString('tr-TR')}</p>
                </div>
              </div>

              {/* User's Artists */}
              {selectedUser.artists.length > 0 && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-3">Kayıtlı Sanatçıları</label>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {selectedUser.artists.map((artist, index) => (
                      <div key={artist.id} className="bg-purple-50 border border-purple-200 rounded-lg p-3">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-purple-500 rounded-lg flex items-center justify-center">
                            <User className="w-4 h-4 text-white" />
                          </div>
                          <div>
                            <p className="font-medium text-purple-900">{artist.name}</p>
                            <p className="text-xs text-purple-700">Sanatçı #{index + 1}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminUsers;