import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useSongs } from '../contexts/SongContext';
import StatCard from '../components/Dashboard/StatCard';
import WarningPanel from '../components/Dashboard/WarningPanel';
import { Music, Clock, CheckCircle, Calendar, DollarSign, Users } from 'lucide-react';
import { PACKAGE_LIMITS } from '../types';

const Dashboard: React.FC = () => {
  const { user } = useAuth();
  const { getSongsByUser } = useSongs();

  if (!user) return null;

  const userSongs = getSongsByUser(user.id);
  const remainingArtistSlots = PACKAGE_LIMITS[user.package] - user.artistCount;

  // Calculate real stats from user's actual data
  const stats = {
    totalSongs: userSongs.length,
    reviewSongs: userSongs.filter(s => s.status === 'review').length,
    approvedSongs: userSongs.filter(s => s.status === 'approved').length,
    distributedSongs: userSongs.filter(s => s.status === 'distributed').length,
    plannedReleases: userSongs.filter(s => new Date(s.releaseDate) > new Date()).length
  };

  // Recent activities based on user's actual songs
  const recentActivities = userSongs
    .sort((a, b) => new Date(b.submittedDate).getTime() - new Date(a.submittedDate).getTime())
    .slice(0, 3)
    .map(song => ({
      action: song.status === 'review' ? 'Şarkı gönderildi' : 
              song.status === 'approved' ? 'Şarkı onaylandı' :
              song.status === 'distributed' ? 'Şarkı dağıtıldı' : 'Şarkı güncellendi',
      title: song.title,
      time: `${Math.floor((Date.now() - new Date(song.submittedDate).getTime()) / (1000 * 60 * 60 * 24))} gün önce`,
      status: song.status
    }));

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-purple-600 to-blue-600 rounded-2xl text-white p-8">
        <h1 className="text-3xl font-bold mb-2">
          Hoş Geldiniz, {user.username}!
        </h1>
        <p className="text-purple-100 text-lg">
          Müzik kariyerinizi yönetmek için tüm araçlarınız burada.
        </p>
      </div>

      {/* Warning Panel */}
      <WarningPanel />

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        <StatCard
          title="Toplam Şarkı"
          value={stats.totalSongs.toString()}
          subtitle="Gönderilen"
          icon={Music}
          color="purple"
        />
        
        <StatCard
          title="İncelemede"
          value={stats.reviewSongs.toString()}
          subtitle="Şarkı"
          icon={Clock}
          color="orange"
        />
        
        <StatCard
          title="Onaylandı"
          value={stats.approvedSongs.toString()}
          subtitle="Yayın"
          icon={CheckCircle}
          color="green"
        />
        
        <StatCard
          title="Dağıtılan"
          value={stats.distributedSongs.toString()}
          subtitle="Şarkı"
          icon={CheckCircle}
          color="blue"
        />
        
        <StatCard
          title="Toplam Kazanç"
          value={`₺${user.totalEarnings.toLocaleString('tr-TR', { minimumFractionDigits: 2 })}`}
          subtitle="Toplam"
          icon={DollarSign}
          color="green"
        />
        
        <StatCard
          title="Sanatçı Kontenjanı"
          value={`${user.artistCount}/${PACKAGE_LIMITS[user.package] === 999 ? '∞' : PACKAGE_LIMITS[user.package]}`}
          subtitle={`${remainingArtistSlots > 0 ? `${remainingArtistSlots} kalan` : 'Limit doldu'}`}
          icon={Users}
          color={remainingArtistSlots > 0 ? 'blue' : 'red'}
        />
      </div>

      {/* Recent Activity */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Son Aktiviteler</h2>
        
        {recentActivities.length === 0 ? (
          <div className="text-center py-8">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Music className="w-8 h-8 text-gray-400" />
            </div>
            <p className="text-gray-600">Henüz aktivite bulunmuyor</p>
            <p className="text-sm text-gray-500 mt-1">İlk şarkınızı göndererek başlayın</p>
          </div>
        ) : (
          <div className="space-y-4">
            {recentActivities.map((activity, index) => (
              <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className={`w-3 h-3 rounded-full ${
                    activity.status === 'review' ? 'bg-orange-400' :
                    activity.status === 'approved' ? 'bg-green-400' :
                    activity.status === 'distributed' ? 'bg-blue-400' :
                    'bg-gray-400'
                  }`}></div>
                  <div>
                    <p className="font-medium text-gray-900">{activity.action}</p>
                    <p className="text-sm text-gray-600">{activity.title}</p>
                  </div>
                </div>
                <span className="text-sm text-gray-500">{activity.time}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Quick Actions for New Users */}
      {stats.totalSongs === 0 && (
        <div className="bg-gradient-to-r from-green-50 to-blue-50 border border-green-200 rounded-xl p-6">
          <div className="text-center">
            <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <Music className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Müzik Yolculuğunuza Başlayın!</h3>
            <p className="text-gray-600 mb-6">
              Henüz hiç şarkı göndermediniz. İlk adımı atarak müzik kariyerinizi başlatın.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-md mx-auto">
              <a
                href="/artists"
                className="flex items-center justify-center space-x-2 px-6 py-3 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200 transition-colors"
              >
                <Users className="w-5 h-5" />
                <span>Sanatçı Ekle</span>
              </a>
              <a
                href="/submit"
                className="flex items-center justify-center space-x-2 px-6 py-3 bg-green-100 text-green-700 rounded-lg hover:bg-green-200 transition-colors"
              >
                <Music className="w-5 h-5" />
                <span>Şarkı Gönder</span>
              </a>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;