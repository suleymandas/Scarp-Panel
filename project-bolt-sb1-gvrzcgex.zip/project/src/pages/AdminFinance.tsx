import React, { useState } from 'react';
import { DollarSign, TrendingUp, Users, CreditCard, Check, X, Clock, Eye, Download, Edit, Plus } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

interface WithdrawalRequest {
  id: string;
  userId: string;
  username: string;
  email: string;
  amount: number;
  requestDate: string;
  status: 'pending' | 'approved' | 'completed' | 'rejected';
  bankInfo: string;
  rejectionReason?: string;
  processedDate?: string;
}

interface UserFinancial {
  userId: string;
  username: string;
  email: string;
  totalEarnings: number;
  totalWithdrawn: number;
  pendingWithdrawals: number;
  availableBalance: number;
  lastWithdrawal?: string;
}

interface FinancialEntry {
  id: string;
  userId: string;
  platform: string;
  amount: number;
  month: string;
  description: string;
}

const AdminFinance: React.FC = () => {
  const { getAllUsers } = useAuth();
  
  // Load real withdrawal data from localStorage
  const [withdrawals, setWithdrawals] = useState<WithdrawalRequest[]>(() => {
    const saved = localStorage.getItem('admin_withdrawals');
    return saved ? JSON.parse(saved) : [];
  });

  // Load real user financial data
  const [userFinancials, setUserFinancials] = useState<UserFinancial[]>(() => {
    const allUsers = getAllUsers();
    return allUsers.filter(user => user.role === 'artist').map(user => ({
      userId: user.id,
      username: user.username,
      email: user.username + '@example.com',
      totalEarnings: user.totalEarnings,
      totalWithdrawn: 0,
      pendingWithdrawals: 0,
      availableBalance: user.totalEarnings,
      lastWithdrawal: undefined
    }));
  });

  const [financialEntries, setFinancialEntries] = useState<FinancialEntry[]>(() => {
    const saved = localStorage.getItem('admin_financial_entries');
    return saved ? JSON.parse(saved) : [];
  });

  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [selectedWithdrawal, setSelectedWithdrawal] = useState<WithdrawalRequest | null>(null);
  const [showWithdrawalModal, setShowWithdrawalModal] = useState(false);
  const [rejectionReason, setRejectionReason] = useState('');
  const [activeTab, setActiveTab] = useState<'withdrawals' | 'users' | 'manage'>('withdrawals');
  
  // Financial Management States
  const [showEditModal, setShowEditModal] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedUser, setSelectedUser] = useState<UserFinancial | null>(null);
  const [editForm, setEditForm] = useState({
    totalEarnings: 0,
    totalWithdrawn: 0,
    pendingWithdrawals: 0
  });
  const [addForm, setAddForm] = useState({
    userId: '',
    platform: '',
    amount: 0,
    month: '',
    description: ''
  });

  // Save data to localStorage
  const saveWithdrawals = (data: WithdrawalRequest[]) => {
    setWithdrawals(data);
    localStorage.setItem('admin_withdrawals', JSON.stringify(data));
  };

  const saveFinancialEntries = (data: FinancialEntry[]) => {
    setFinancialEntries(data);
    localStorage.setItem('admin_financial_entries', JSON.stringify(data));
  };

  const filteredWithdrawals = withdrawals.filter(withdrawal => {
    return filterStatus === 'all' || withdrawal.status === filterStatus;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-orange-100 text-orange-800';
      case 'approved':
        return 'bg-blue-100 text-blue-800';
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'rejected':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'pending':
        return 'Beklemede';
      case 'approved':
        return 'Onaylandı';
      case 'completed':
        return 'Tamamlandı';
      case 'rejected':
        return 'Reddedildi';
      default:
        return 'Bilinmiyor';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending':
        return <Clock className="w-4 h-4" />;
      case 'approved':
        return <Check className="w-4 h-4" />;
      case 'completed':
        return <Check className="w-4 h-4" />;
      case 'rejected':
        return <X className="w-4 h-4" />;
      default:
        return <Clock className="w-4 h-4" />;
    }
  };

  const handleWithdrawalAction = (action: string, withdrawalId: string, reason?: string) => {
    const updatedWithdrawals = withdrawals.map(withdrawal => {
      if (withdrawal.id === withdrawalId) {
        switch (action) {
          case 'approve':
            return { ...withdrawal, status: 'approved' as const };
          case 'complete':
            return { ...withdrawal, status: 'completed' as const, processedDate: new Date().toISOString().split('T')[0] };
          case 'reject':
            return { ...withdrawal, status: 'rejected' as const, rejectionReason: reason };
          default:
            return withdrawal;
        }
      }
      return withdrawal;
    });
    
    saveWithdrawals(updatedWithdrawals);
    setShowWithdrawalModal(false);
    setRejectionReason('');
  };

  const handleEditUser = (user: UserFinancial) => {
    setSelectedUser(user);
    setEditForm({
      totalEarnings: user.totalEarnings,
      totalWithdrawn: user.totalWithdrawn,
      pendingWithdrawals: user.pendingWithdrawals
    });
    setShowEditModal(true);
  };

  const handleSaveEdit = () => {
    if (!selectedUser) return;
    
    const availableBalance = editForm.totalEarnings - editForm.totalWithdrawn - editForm.pendingWithdrawals;
    
    setUserFinancials(userFinancials.map(user => 
      user.userId === selectedUser.userId 
        ? { 
            ...user, 
            totalEarnings: editForm.totalEarnings,
            totalWithdrawn: editForm.totalWithdrawn,
            pendingWithdrawals: editForm.pendingWithdrawals,
            availableBalance: availableBalance
          }
        : user
    ));
    
    setShowEditModal(false);
    setSelectedUser(null);
  };

  const handleAddFinancialEntry = () => {
    if (!addForm.userId || !addForm.platform || !addForm.amount || !addForm.month) {
      alert('Lütfen tüm gerekli alanları doldurun.');
      return;
    }

    const newEntry: FinancialEntry = {
      id: Date.now().toString(),
      ...addForm
    };

    const updatedEntries = [...financialEntries, newEntry];
    saveFinancialEntries(updatedEntries);

    // Update user's total earnings
    setUserFinancials(userFinancials.map(user => {
      if (user.userId === addForm.userId) {
        const newTotalEarnings = user.totalEarnings + addForm.amount;
        const newAvailableBalance = newTotalEarnings - user.totalWithdrawn - user.pendingWithdrawals;
        return {
          ...user,
          totalEarnings: newTotalEarnings,
          availableBalance: newAvailableBalance
        };
      }
      return user;
    }));

    setAddForm({
      userId: '',
      platform: '',
      amount: 0,
      month: '',
      description: ''
    });
    setShowAddModal(false);
  };

  const totalStats = {
    totalWithdrawals: withdrawals.length,
    pendingWithdrawals: withdrawals.filter(w => w.status === 'pending').length,
    completedWithdrawals: withdrawals.filter(w => w.status === 'completed').length,
    totalAmount: withdrawals.reduce((sum, w) => sum + w.amount, 0),
    pendingAmount: withdrawals.filter(w => w.status === 'pending').reduce((sum, w) => sum + w.amount, 0),
    completedAmount: withdrawals.filter(w => w.status === 'completed').reduce((sum, w) => sum + w.amount, 0)
  };

  const userStats = {
    totalUsers: userFinancials.length,
    totalEarnings: userFinancials.reduce((sum, u) => sum + u.totalEarnings, 0),
    totalWithdrawn: userFinancials.reduce((sum, u) => sum + u.totalWithdrawn, 0),
    totalAvailable: userFinancials.reduce((sum, u) => sum + u.availableBalance, 0)
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-green-600 to-blue-600 rounded-2xl text-white p-8">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
            <DollarSign className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-3xl font-bold">Finans Paneli</h1>
            <p className="text-green-100 mt-1">Para çekim talepleri ve kullanıcı finansal durumu</p>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            <button
              onClick={() => setActiveTab('withdrawals')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'withdrawals'
                  ? 'border-green-500 text-green-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Para Çekim Talepleri
            </button>
            <button
              onClick={() => setActiveTab('users')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'users'
                  ? 'border-green-500 text-green-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Kullanıcı Finansal Durumu
            </button>
            <button
              onClick={() => setActiveTab('manage')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'manage'
                  ? 'border-green-500 text-green-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Finansal Veri Yönetimi
            </button>
          </nav>
        </div>

        {activeTab === 'withdrawals' && (
          <div className="p-6">
            {/* Withdrawal Stats */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <div className="bg-gradient-to-r from-blue-50 to-blue-100 rounded-xl p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-blue-600">Toplam Talep</p>
                    <p className="text-2xl font-bold text-blue-900">{totalStats.totalWithdrawals}</p>
                  </div>
                  <CreditCard className="w-8 h-8 text-blue-500" />
                </div>
              </div>

              <div className="bg-gradient-to-r from-orange-50 to-orange-100 rounded-xl p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-orange-600">Bekleyen</p>
                    <p className="text-2xl font-bold text-orange-900">{totalStats.pendingWithdrawals}</p>
                  </div>
                  <Clock className="w-8 h-8 text-orange-500" />
                </div>
              </div>

              <div className="bg-gradient-to-r from-green-50 to-green-100 rounded-xl p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-green-600">Tamamlanan</p>
                    <p className="text-2xl font-bold text-green-900">{totalStats.completedWithdrawals}</p>
                  </div>
                  <Check className="w-8 h-8 text-green-500" />
                </div>
              </div>

              <div className="bg-gradient-to-r from-purple-50 to-purple-100 rounded-xl p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-purple-600">Toplam Tutar</p>
                    <p className="text-2xl font-bold text-purple-900">
                      ₺{totalStats.totalAmount.toLocaleString('tr-TR')}
                    </p>
                  </div>
                  <DollarSign className="w-8 h-8 text-purple-500" />
                </div>
              </div>
            </div>

            {/* Filter */}
            <div className="mb-6">
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              >
                <option value="all">Tüm Durumlar</option>
                <option value="pending">Beklemede</option>
                <option value="approved">Onaylandı</option>
                <option value="completed">Tamamlandı</option>
                <option value="rejected">Reddedildi</option>
              </select>
            </div>

            {/* No Withdrawals Message */}
            {filteredWithdrawals.length === 0 && (
              <div className="text-center py-12">
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CreditCard className="w-8 h-8 text-gray-400" />
                </div>
                <p className="text-gray-600">Henüz para çekim talebi bulunmuyor</p>
                <p className="text-sm text-gray-500 mt-1">
                  Kullanıcılar para çekim talebinde bulunduğunda burada görünecektir
                </p>
              </div>
            )}
          </div>
        )}

        {activeTab === 'users' && (
          <div className="p-6">
            {/* User Financial Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
              <div className="bg-gradient-to-r from-blue-50 to-blue-100 rounded-xl p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-blue-600">Toplam Kullanıcı</p>
                    <p className="text-2xl font-bold text-blue-900">{userStats.totalUsers}</p>
                  </div>
                  <Users className="w-8 h-8 text-blue-500" />
                </div>
              </div>

              <div className="bg-gradient-to-r from-green-50 to-green-100 rounded-xl p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-green-600">Toplam Gelir</p>
                    <p className="text-2xl font-bold text-green-900">
                      ₺{userStats.totalEarnings.toLocaleString('tr-TR')}
                    </p>
                  </div>
                  <TrendingUp className="w-8 h-8 text-green-500" />
                </div>
              </div>

              <div className="bg-gradient-to-r from-purple-50 to-purple-100 rounded-xl p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-purple-600">Çekilen Tutar</p>
                    <p className="text-2xl font-bold text-purple-900">
                      ₺{userStats.totalWithdrawn.toLocaleString('tr-TR')}
                    </p>
                  </div>
                  <CreditCard className="w-8 h-8 text-purple-500" />
                </div>
              </div>

              <div className="bg-gradient-to-r from-orange-50 to-orange-100 rounded-xl p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-orange-600">Çekilebilir</p>
                    <p className="text-2xl font-bold text-orange-900">
                      ₺{userStats.totalAvailable.toLocaleString('tr-TR')}
                    </p>
                  </div>
                  <DollarSign className="w-8 h-8 text-orange-500" />
                </div>
              </div>
            </div>

            {/* Users Financial Table */}
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Kullanıcı
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Toplam Gelir
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Çekilen
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Bekleyen
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Çekilebilir
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Son Çekim
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      İşlemler
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {userFinancials.map((user) => (
                    <tr key={user.userId} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="w-10 h-10 bg-gradient-to-r from-green-500 to-blue-500 rounded-full flex items-center justify-center">
                            <span className="text-white font-medium text-sm">
                              {user.username.charAt(0).toUpperCase()}
                            </span>
                          </div>
                          <div className="ml-4">
                            <div className="text-sm font-medium text-gray-900">{user.username}</div>
                            <div className="text-sm text-gray-500">{user.email}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        ₺{user.totalEarnings.toLocaleString('tr-TR', { minimumFractionDigits: 2 })}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        ₺{user.totalWithdrawn.toLocaleString('tr-TR', { minimumFractionDigits: 2 })}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-orange-600 font-medium">
                        ₺{user.pendingWithdrawals.toLocaleString('tr-TR', { minimumFractionDigits: 2 })}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <span className={user.availableBalance >= 750 ? 'text-green-600' : 'text-red-600'}>
                          ₺{user.availableBalance.toLocaleString('tr-TR', { minimumFractionDigits: 2 })}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {user.lastWithdrawal ? new Date(user.lastWithdrawal).toLocaleDateString('tr-TR') : 'Hiç çekim yok'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <button
                          onClick={() => handleEditUser(user)}
                          className="flex items-center space-x-1 px-3 py-1 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200 transition-colors"
                        >
                          <Edit className="w-4 h-4" />
                          <span>Düzenle</span>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'manage' && (
          <div className="p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-gray-900">Finansal Veri Yönetimi</h3>
              <button
                onClick={() => setShowAddModal(true)}
                className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
              >
                <Plus className="w-4 h-4" />
                <span>Gelir Ekle</span>
              </button>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
              <h4 className="font-medium text-blue-900 mb-2">Finansal Veri Yönetimi</h4>
              <p className="text-sm text-blue-800">
                Bu bölümden kullanıcıların finansal verilerini düzenleyebilir ve yeni gelir kayıtları ekleyebilirsiniz.
                Tüm değişiklikler otomatik olarak kullanıcının çekilebilir bakiyesini günceller.
              </p>
            </div>

            {/* Recent Financial Entries */}
            <div className="bg-white border border-gray-200 rounded-lg">
              <div className="p-4 border-b border-gray-200">
                <h4 className="font-medium text-gray-900">Son Eklenen Gelir Kayıtları</h4>
              </div>
              
              {financialEntries.length === 0 ? (
                <div className="p-12 text-center">
                  <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <DollarSign className="w-8 h-8 text-gray-400" />
                  </div>
                  <p className="text-gray-600">Henüz gelir kaydı eklenmemiş</p>
                  <p className="text-sm text-gray-500 mt-1">
                    Kullanıcılar için gelir kayıtları ekleyerek başlayın
                  </p>
                </div>
              ) : (
                <div className="divide-y divide-gray-200">
                  {financialEntries.slice(-10).map((entry) => {
                    const user = userFinancials.find(u => u.userId === entry.userId);
                    return (
                      <div key={entry.id} className="p-4 flex items-center justify-between">
                        <div>
                          <p className="font-medium text-gray-900">{user?.username || 'Bilinmeyen Kullanıcı'}</p>
                          <p className="text-sm text-gray-600">{entry.platform} - {entry.month}</p>
                          <p className="text-xs text-gray-500">{entry.description}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-bold text-green-600">
                            +₺{entry.amount.toLocaleString('tr-TR', { minimumFractionDigits: 2 })}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Edit User Financial Modal */}
      {showEditModal && selectedUser && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 max-w-md w-full mx-4">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-semibold text-gray-900">Finansal Veri Düzenle</h3>
              <button
                onClick={() => setShowEditModal(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Kullanıcı: {selectedUser.username}
                </label>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Toplam Gelir (₺)
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={editForm.totalEarnings}
                  onChange={(e) => setEditForm({ ...editForm, totalEarnings: parseFloat(e.target.value) || 0 })}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Çekilen Tutar (₺)
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={editForm.totalWithdrawn}
                  onChange={(e) => setEditForm({ ...editForm, totalWithdrawn: parseFloat(e.target.value) || 0 })}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Bekleyen Çekim (₺)
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={editForm.pendingWithdrawals}
                  onChange={(e) => setEditForm({ ...editForm, pendingWithdrawals: parseFloat(e.target.value) || 0 })}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
              </div>

              <div className="bg-gray-50 p-3 rounded-lg">
                <p className="text-sm text-gray-600">
                  <strong>Çekilebilir Bakiye:</strong> ₺{(editForm.totalEarnings - editForm.totalWithdrawn - editForm.pendingWithdrawals).toLocaleString('tr-TR', { minimumFractionDigits: 2 })}
                </p>
              </div>

              <div className="flex space-x-4">
                <button
                  onClick={handleSaveEdit}
                  className="flex-1 bg-green-600 text-white py-3 px-4 rounded-lg hover:bg-green-700 transition-colors"
                >
                  Kaydet
                </button>
                <button
                  onClick={() => setShowEditModal(false)}
                  className="flex-1 bg-gray-300 text-gray-700 py-3 px-4 rounded-lg hover:bg-gray-400 transition-colors"
                >
                  İptal
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Add Financial Entry Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 max-w-md w-full mx-4">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-semibold text-gray-900">Gelir Kaydı Ekle</h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Kullanıcı *
                </label>
                <select
                  value={addForm.userId}
                  onChange={(e) => setAddForm({ ...addForm, userId: e.target.value })}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  required
                >
                  <option value="">Kullanıcı seçin</option>
                  {userFinancials.map((user) => (
                    <option key={user.userId} value={user.userId}>
                      {user.username} ({user.email})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Platform *
                </label>
                <select
                  value={addForm.platform}
                  onChange={(e) => setAddForm({ ...addForm, platform: e.target.value })}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  required
                >
                  <option value="">Platform seçin</option>
                  <option value="Spotify">Spotify</option>
                  <option value="Apple Music">Apple Music</option>
                  <option value="YouTube Music">YouTube Music</option>
                  <option value="Deezer">Deezer</option>
                  <option value="Amazon Music">Amazon Music</option>
                  <option value="Diğer">Diğer</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Tutar (₺) *
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={addForm.amount}
                  onChange={(e) => setAddForm({ ...addForm, amount: parseFloat(e.target.value) || 0 })}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  placeholder="0.00"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Ay *
                </label>
                <input
                  type="month"
                  value={addForm.month}
                  onChange={(e) => setAddForm({ ...addForm, month: e.target.value })}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Açıklama
                </label>
                <textarea
                  value={addForm.description}
                  onChange={(e) => setAddForm({ ...addForm, description: e.target.value })}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  rows={3}
                  placeholder="Gelir kaydı açıklaması..."
                />
              </div>

              <div className="flex space-x-4">
                <button
                  onClick={handleAddFinancialEntry}
                  className="flex-1 bg-green-600 text-white py-3 px-4 rounded-lg hover:bg-green-700 transition-colors"
                >
                  Ekle
                </button>
                <button
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 bg-gray-300 text-gray-700 py-3 px-4 rounded-lg hover:bg-gray-400 transition-colors"
                >
                  İptal
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminFinance;