import React, { useState, useEffect } from 'react';
import { Plus, X, Upload, Calendar, ChevronDown, Music2, User, Check } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useSongs } from '../contexts/SongContext';
import { useNotifications } from '../contexts/NotificationContext';
import { useNavigate } from 'react-router-dom';

interface Artist {
  name: string;
  spotifyLink: string;
  appleMusicLink: string;
}

interface Track {
  fileLink: string;
  trackName: string;
  isrcCode: string;
  hasExplicitContent: boolean;
  youtubeContentId: boolean;
  primaryArtists: Artist[];
  featuredArtists: Artist[];
  songwriter: string;
  composer: string;
  language: string;
  genre: string;
}

const SubmitSong: React.FC = () => {
  const { user } = useAuth();
  const { addSong } = useSongs();
  const { addNotification } = useNotifications();
  const navigate = useNavigate();
  
  const [releaseType, setReleaseType] = useState<'single' | 'ep' | 'album' | 'composition'>('single');
  const [albumCover, setAlbumCover] = useState('');
  const [selectedPrimaryArtists, setSelectedPrimaryArtists] = useState<string[]>([]);
  const [showArtistDropdown, setShowArtistDropdown] = useState(false);
  const [featuredArtists, setFeaturedArtists] = useState<Artist[]>([]);
  const [upcCode, setUpcCode] = useState('');
  const [albumName, setAlbumName] = useState('');
  const [albumType, setAlbumType] = useState('');
  const [albumLanguage, setAlbumLanguage] = useState('tr');
  const [releaseStatus, setReleaseStatus] = useState<'previously_released' | 'new_release'>('new_release');
  const [originalReleaseDate, setOriginalReleaseDate] = useState('');
  const [newReleaseDate, setNewReleaseDate] = useState('');
  const [tracks, setTracks] = useState<Track[]>([{
    fileLink: '',
    trackName: '',
    isrcCode: '',
    hasExplicitContent: false,
    youtubeContentId: false,
    primaryArtists: [],
    featuredArtists: [],
    songwriter: '',
    composer: '',
    language: 'tr',
    genre: ''
  }]);

  if (!user) return null;

  // Load user-specific artists
  const registeredArtists = (() => {
    const savedArtists = localStorage.getItem(`artists_${user.id}`);
    return savedArtists ? JSON.parse(savedArtists) : [];
  })();

  // Track limits based on release type
  const getTrackLimits = () => {
    switch (releaseType) {
      case 'single':
        return { min: 1, max: 1 };
      case 'ep':
        return { min: 3, max: 6 };
      case 'album':
        return { min: 7, max: 25 };
      case 'composition':
        return { min: 26, max: 50 };
      default:
        return { min: 1, max: 1 };
    }
  };

  const trackLimits = getTrackLimits();
  const canAddTrack = tracks.length < trackLimits.max;
  const canRemoveTrack = tracks.length > trackLimits.min;

  // Reset tracks when release type changes
  useEffect(() => {
    const limits = getTrackLimits();
    if (tracks.length < limits.min) {
      // Add tracks to meet minimum
      const newTracks = [...tracks];
      while (newTracks.length < limits.min) {
        newTracks.push({
          fileLink: '',
          trackName: '',
          isrcCode: '',
          hasExplicitContent: false,
          youtubeContentId: false,
          primaryArtists: [],
          featuredArtists: [],
          songwriter: '',
          composer: '',
          language: 'tr',
          genre: ''
        });
      }
      setTracks(newTracks);
    } else if (tracks.length > limits.max) {
      // Remove excess tracks
      setTracks(tracks.slice(0, limits.max));
    }
  }, [releaseType]);

  const handlePrimaryArtistSelect = (artistId: string) => {
    if (selectedPrimaryArtists.includes(artistId)) {
      setSelectedPrimaryArtists(selectedPrimaryArtists.filter(id => id !== artistId));
    } else {
      if (selectedPrimaryArtists.length >= 1 && user.package === 'starter') {
        alert('Starter paketinde sadece 1 birincil sanatçı seçebilirsiniz. Daha fazla sanatçı için Scarp Music ile iletişime geçin.');
        return;
      }
      if (selectedPrimaryArtists.length >= 3 && user.package === 'pro') {
        alert('Pro paketinde en fazla 3 birincil sanatçı seçebilirsiniz. Daha fazla sanatçı için Scarp Music ile iletişime geçin.');
        return;
      }
      setSelectedPrimaryArtists([...selectedPrimaryArtists, artistId]);
    }
  };

  const addFeaturedArtist = () => {
    setFeaturedArtists([...featuredArtists, { name: '', spotifyLink: '', appleMusicLink: '' }]);
  };

  const removeFeaturedArtist = (index: number) => {
    setFeaturedArtists(featuredArtists.filter((_, i) => i !== index));
  };

  const addTrack = () => {
    if (canAddTrack) {
      setTracks([...tracks, {
        fileLink: '',
        trackName: '',
        isrcCode: '',
        hasExplicitContent: false,
        youtubeContentId: false,
        primaryArtists: [],
        featuredArtists: [],
        songwriter: '',
        composer: '',
        language: 'tr',
        genre: ''
      }]);
    }
  };

  const removeTrack = (index: number) => {
    if (canRemoveTrack) {
      setTracks(tracks.filter((_, i) => i !== index));
    }
  };

  const updateTrack = (index: number, field: keyof Track, value: any) => {
    const updated = [...tracks];
    updated[index] = { ...updated[index], [field]: value };
    setTracks(updated);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedPrimaryArtists.length === 0) {
      alert('En az bir birincil sanatçı seçmelisiniz.');
      return;
    }

    // Validate track count
    if (tracks.length < trackLimits.min || tracks.length > trackLimits.max) {
      alert(`${releaseType.toUpperCase()} için ${trackLimits.min}-${trackLimits.max} parça arasında olmalıdır.`);
      return;
    }

    // Validate all tracks
    for (let i = 0; i < tracks.length; i++) {
      const track = tracks[i];
      if (!track.trackName || !track.fileLink || !track.genre) {
        alert(`Parça ${i + 1} için tüm zorunlu alanları doldurun.`);
        return;
      }
    }

    // Get selected primary artists data
    const primaryArtistsData = selectedPrimaryArtists.map(artistId => {
      const artist = registeredArtists.find((a: any) => a.id === artistId);
      return artist ? {
        name: artist.name,
        spotifyLink: artist.spotifyLink,
        appleMusicLink: artist.appleMusicLink
      } : { name: '', spotifyLink: '', appleMusicLink: '' };
    });

    // Create artist name string for display
    const artistNames = primaryArtistsData.map(a => a.name).join(', ');
    const featuredNames = featuredArtists.filter(a => a.name).map(a => a.name);
    const fullArtistName = featuredNames.length > 0 
      ? `${artistNames} ft. ${featuredNames.join(', ')}`
      : artistNames;

    // For single releases, use the first track's data
    // For multi-track releases, create separate songs for each track
    if (releaseType === 'single') {
      const mainTrack = tracks[0];
      const songData = {
        title: mainTrack.trackName,
        artist: fullArtistName,
        userId: user.id,
        username: user.username,
        albumCover,
        genre: mainTrack.genre,
        releaseType,
        releaseDate: releaseStatus === 'new_release' ? newReleaseDate : originalReleaseDate,
        fileLink: mainTrack.fileLink,
        isrcCode: mainTrack.isrcCode || `TR-SCR-${Date.now()}`,
        hasExplicitContent: mainTrack.hasExplicitContent,
        youtubeContentId: mainTrack.youtubeContentId,
        language: mainTrack.language,
        primaryArtists: primaryArtistsData,
        featuredArtists: featuredArtists.filter(a => a.name)
      };

      addSong(songData);

      addNotification({
        userId: user.id,
        title: '📤 Şarkı Gönderildi!',
        message: `"${mainTrack.trackName}" adlı şarkınız başarıyla gönderildi ve inceleme sürecine alındı.`,
        type: 'info',
        relatedSongTitle: mainTrack.trackName,
        actionType: 'general'
      });

      alert('Şarkı başarıyla gönderildi!');
    } else {
      // For EP/Album, create separate songs for each track
      tracks.forEach((track, index) => {
        const songData = {
          title: track.trackName,
          artist: fullArtistName,
          userId: user.id,
          username: user.username,
          albumCover,
          genre: track.genre,
          releaseType,
          releaseDate: releaseStatus === 'new_release' ? newReleaseDate : originalReleaseDate,
          fileLink: track.fileLink,
          isrcCode: track.isrcCode || `TR-SCR-${Date.now()}-${index + 1}`,
          hasExplicitContent: track.hasExplicitContent,
          youtubeContentId: track.youtubeContentId,
          language: track.language,
          primaryArtists: primaryArtistsData,
          featuredArtists: featuredArtists.filter(a => a.name)
        };

        addSong(songData);
      });

      addNotification({
        userId: user.id,
        title: `📤 ${releaseType.toUpperCase()} Gönderildi!`,
        message: `"${albumName}" adlı ${releaseType} (${tracks.length} parça) başarıyla gönderildi ve inceleme sürecine alındı.`,
        type: 'info',
        relatedSongTitle: albumName,
        actionType: 'general'
      });

      alert(`${releaseType.toUpperCase()} başarıyla gönderildi! ${tracks.length} parça inceleme sürecine alınmıştır.`);
    }
    
    navigate('/catalog');
  };

  // Get minimum date (2 weeks from now)
  const minDate = new Date();
  minDate.setDate(minDate.getDate() + 14);
  const minDateString = minDate.toISOString().split('T')[0];

  const getSelectedArtistNames = () => {
    return selectedPrimaryArtists.map(artistId => {
      const artist = registeredArtists.find((a: any) => a.id === artistId);
      return artist?.name || '';
    }).filter(name => name);
  };

  const getTrackTypeText = () => {
    switch (releaseType) {
      case 'single':
        return 'Şarkı';
      case 'ep':
        return 'EP Parçası';
      case 'album':
        return 'Albüm Parçası';
      case 'composition':
        return 'Kompozisyon';
      default:
        return 'Parça';
    }
  };

  const getReleaseTypeDescription = () => {
    switch (releaseType) {
      case 'single':
        return '1 parça';
      case 'ep':
        return '3-6 parça';
      case 'album':
        return '7-25 parça';
      case 'composition':
        return '26-50 parça';
      default:
        return '';
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-600 to-blue-600 rounded-2xl text-white p-8">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
            <Upload className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-3xl font-bold">Şarkı Gönderme Formu</h1>
            <p className="text-purple-100 mt-1">Yeni yayınınızı platforma gönderin</p>
          </div>
        </div>
      </div>

      {/* Release Code Info */}
      <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
            <span className="text-white text-sm font-bold">#</span>
          </div>
          <div>
            <h3 className="font-semibold text-blue-900">Yayın Kodu Bilgisi</h3>
            <p className="text-sm text-blue-800 mt-1">
              {releaseType === 'single' 
                ? 'Şarkınız gönderildikten sonra otomatik olarak benzersiz bir yayın kodu oluşturulacaktır.'
                : `Her parça için ayrı yayın kodu oluşturulacaktır. Toplam ${tracks.length} parça için ${tracks.length} adet kod oluşturulacak.`
              }
            </p>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="p-8">
          <form onSubmit={handleSubmit} className="space-y-10">
            {/* Basic Release Information */}
            <div className="space-y-6">
              <div className="border-b border-gray-200 pb-4">
                <h2 className="text-xl font-semibold text-gray-900 flex items-center space-x-2">
                  <Music2 className="w-5 h-5 text-purple-600" />
                  <span>Temel Bilgiler</span>
                </h2>
                <p className="text-sm text-gray-600 mt-1">Yayınınızın temel bilgilerini girin</p>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="block text-sm font-medium text-gray-700">
                    Yayın Türü *
                  </label>
                  <select
                    value={releaseType}
                    onChange={(e) => setReleaseType(e.target.value as any)}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-colors"
                    required
                  >
                    <option value="single">Single ({getReleaseTypeDescription()})</option>
                    <option value="ep">EP ({getReleaseTypeDescription()})</option>
                    <option value="album">Albüm ({getReleaseTypeDescription()})</option>
                    <option value="composition">Kompozisyon ({getReleaseTypeDescription()})</option>
                  </select>
                  <p className="text-xs text-gray-500">
                    {releaseType === 'single' && 'Tek şarkı yayını'}
                    {releaseType === 'ep' && 'Extended Play - Kısa albüm formatı'}
                    {releaseType === 'album' && 'Tam albüm formatı'}
                    {releaseType === 'composition' && 'Geniş kompozisyon koleksiyonu'}
                  </p>
                </div>

                <div className="space-y-2">
                  <label className="block text-sm font-medium text-gray-700">
                    Albüm Kapağı URL *
                  </label>
                  <input
                    type="url"
                    value={albumCover}
                    onChange={(e) => setAlbumCover(e.target.value)}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-colors"
                    placeholder="https://example.com/cover.jpg"
                    required
                  />
                  <p className="text-xs text-gray-500">Minimum 3000x3000 piksel, JPG/PNG formatında</p>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <label className="block text-sm font-medium text-gray-700">
                    {releaseType === 'single' ? 'Şarkı Adı' : 'Albüm/EP Adı'} *
                  </label>
                  <input
                    type="text"
                    value={albumName}
                    onChange={(e) => setAlbumName(e.target.value)}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-colors"
                    placeholder={releaseType === 'single' ? 'Şarkı adını girin' : 'Yayın adını girin'}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <label className="block text-sm font-medium text-gray-700">
                    Ana Tür *
                  </label>
                  <select
                    value={albumType}
                    onChange={(e) => setAlbumType(e.target.value)}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-colors"
                    required
                  >
                    <option value="">Tür seçin</option>
                    <option value="pop">Pop</option>
                    <option value="rock">Rock</option>
                    <option value="hip-hop">Hip-Hop</option>
                    <option value="electronic">Elektronik</option>
                    <option value="folk">Folk</option>
                    <option value="jazz">Jazz</option>
                    <option value="classical">Klasik</option>
                    <option value="other">Diğer</option>
                  </select>
                </div>

                <div className="space-y-2">
                  <label className="block text-sm font-medium text-gray-700">
                    Ana Dil *
                  </label>
                  <select
                    value={albumLanguage}
                    onChange={(e) => setAlbumLanguage(e.target.value)}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-colors"
                    required
                  >
                    <option value="tr">Türkçe</option>
                    <option value="en">İngilizce</option>
                    <option value="fr">Fransızca</option>
                    <option value="de">Almanca</option>
                    <option value="es">İspanyolca</option>
                    <option value="other">Diğer</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Artist Selection */}
            <div className="space-y-6">
              <div className="border-b border-gray-200 pb-4">
                <h2 className="text-xl font-semibold text-gray-900 flex items-center space-x-2">
                  <User className="w-5 h-5 text-purple-600" />
                  <span>Sanatçı Seçimi</span>
                </h2>
                <p className="text-sm text-gray-600 mt-1">Birincil sanatçılarınızı seçin</p>
              </div>

              {/* Primary Artists Dropdown */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <label className="block text-sm font-medium text-gray-700">
                    Birincil Sanatçılar *
                  </label>
                  <div className="text-sm text-gray-500">
                    {selectedPrimaryArtists.length} / {user.package === 'starter' ? '1' : user.package === 'pro' ? '3' : '∞'} seçili
                  </div>
                </div>

                {registeredArtists.length === 0 ? (
                  <div className="bg-red-50 border border-red-200 rounded-lg p-6 text-center">
                    <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-3">
                      <User className="w-6 h-6 text-red-600" />
                    </div>
                    <h3 className="font-medium text-red-900 mb-2">Kayıtlı Sanatçı Bulunamadı</h3>
                    <p className="text-sm text-red-700 mb-4">
                      Şarkı gönderebilmek için önce en az bir sanatçı eklemelisiniz.
                    </p>
                    <a
                      href="/artists"
                      className="inline-flex items-center space-x-2 px-4 py-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-200 transition-colors"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Sanatçı Ekle</span>
                    </a>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {/* Selected Artists Display */}
                    {selectedPrimaryArtists.length > 0 && (
                      <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                        <h4 className="text-sm font-medium text-purple-900 mb-3">Seçili Sanatçılar:</h4>
                        <div className="flex flex-wrap gap-2">
                          {getSelectedArtistNames().map((name, index) => (
                            <span
                              key={index}
                              className="inline-flex items-center space-x-1 px-3 py-1 bg-purple-100 text-purple-800 rounded-full text-sm"
                            >
                              <span>{name}</span>
                              <button
                                type="button"
                                onClick={() => {
                                  const artistId = selectedPrimaryArtists[index];
                                  setSelectedPrimaryArtists(selectedPrimaryArtists.filter(id => id !== artistId));
                                }}
                                className="text-purple-600 hover:text-purple-800"
                              >
                                <X className="w-3 h-3" />
                              </button>
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Artist Selection Dropdown */}
                    <div className="relative">
                      <button
                        type="button"
                        onClick={() => setShowArtistDropdown(!showArtistDropdown)}
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-colors flex items-center justify-between bg-white"
                      >
                        <span className="text-gray-700">
                          {selectedPrimaryArtists.length === 0 
                            ? 'Sanatçı seçin...' 
                            : `${selectedPrimaryArtists.length} sanatçı seçili`
                          }
                        </span>
                        <ChevronDown className={`w-5 h-5 text-gray-400 transition-transform ${showArtistDropdown ? 'rotate-180' : ''}`} />
                      </button>

                      {showArtistDropdown && (
                        <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-gray-300 rounded-lg shadow-lg z-10 max-h-60 overflow-y-auto">
                          {registeredArtists.map((artist: any) => (
                            <label
                              key={artist.id}
                              className="flex items-center space-x-3 p-3 hover:bg-gray-50 cursor-pointer border-b border-gray-100 last:border-b-0"
                            >
                              <input
                                type="checkbox"
                                checked={selectedPrimaryArtists.includes(artist.id)}
                                onChange={() => handlePrimaryArtistSelect(artist.id)}
                                className="w-4 h-4 text-purple-600 rounded focus:ring-purple-500"
                              />
                              <div className="flex-1">
                                <p className="font-medium text-gray-900">{artist.name}</p>
                                <p className="text-xs text-gray-500">Birincil Sanatçı</p>
                              </div>
                              {selectedPrimaryArtists.includes(artist.id) && (
                                <Check className="w-4 h-4 text-purple-600" />
                              )}
                            </label>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>

              {/* Featured Artists */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <label className="block text-sm font-medium text-gray-700">
                    Düet Sanatçıları (ft.) - Opsiyonel
                  </label>
                  <button
                    type="button"
                    onClick={addFeaturedArtist}
                    className="flex items-center space-x-2 px-3 py-1 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200 transition-colors text-sm"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Düet Ekle</span>
                  </button>
                </div>

                {featuredArtists.map((artist, index) => (
                  <div key={index} className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="font-medium text-blue-900">Düet Sanatçısı {index + 1}</h4>
                      <button
                        type="button"
                        onClick={() => removeFeaturedArtist(index)}
                        className="text-red-600 hover:text-red-800"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <label className="block text-xs font-medium text-blue-700">
                          Ad Soyad *
                        </label>
                        <input
                          type="text"
                          value={artist.name}
                          onChange={(e) => {
                            const updated = [...featuredArtists];
                            updated[index].name = e.target.value;
                            setFeaturedArtists(updated);
                          }}
                          className="w-full p-2 border border-blue-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                          placeholder="Sanatçı adı"
                          required
                        />
                      </div>

                      <div className="space-y-2">
                        <label className="block text-xs font-medium text-blue-700">
                          Spotify Link
                        </label>
                        <input
                          type="url"
                          value={artist.spotifyLink}
                          onChange={(e) => {
                            const updated = [...featuredArtists];
                            updated[index].spotifyLink = e.target.value;
                            setFeaturedArtists(updated);
                          }}
                          className="w-full p-2 border border-blue-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                          placeholder="https://open.spotify.com/..."
                        />
                      </div>

                      <div className="space-y-2">
                        <label className="block text-xs font-medium text-blue-700">
                          Apple Music Link
                        </label>
                        <input
                          type="url"
                          value={artist.appleMusicLink}
                          onChange={(e) => {
                            const updated = [...featuredArtists];
                            updated[index].appleMusicLink = e.target.value;
                            setFeaturedArtists(updated);
                          }}
                          className="w-full p-2 border border-blue-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                          placeholder="https://music.apple.com/..."
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Release Date */}
            <div className="space-y-6">
              <div className="border-b border-gray-200 pb-4">
                <h2 className="text-xl font-semibold text-gray-900 flex items-center space-x-2">
                  <Calendar className="w-5 h-5 text-purple-600" />
                  <span>Yayın Tarihi</span>
                </h2>
                <p className="text-sm text-gray-600 mt-1">Şarkınızın yayın durumunu belirtin</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <label className="flex items-center space-x-3 p-4 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50 transition-colors">
                    <input
                      type="radio"
                      name="releaseStatus"
                      value="previously_released"
                      checked={releaseStatus === 'previously_released'}
                      onChange={(e) => setReleaseStatus(e.target.value as any)}
                      className="w-4 h-4 text-purple-600"
                    />
                    <div>
                      <p className="font-medium text-gray-900">Daha önce yayınlandı</p>
                      <p className="text-sm text-gray-600">Bu şarkı daha önce başka platformlarda yayınlandı</p>
                    </div>
                  </label>
                  {releaseStatus === 'previously_released' && (
                    <div className="ml-7 space-y-2">
                      <label className="block text-sm font-medium text-gray-700">
                        Orijinal Yayın Tarihi *
                      </label>
                      <input
                        type="date"
                        value={originalReleaseDate}
                        onChange={(e) => setOriginalReleaseDate(e.target.value)}
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                        required={releaseStatus === 'previously_released'}
                      />
                    </div>
                  )}
                </div>

                <div className="space-y-4">
                  <label className="flex items-center space-x-3 p-4 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50 transition-colors">
                    <input
                      type="radio"
                      name="releaseStatus"
                      value="new_release"
                      checked={releaseStatus === 'new_release'}
                      onChange={(e) => setReleaseStatus(e.target.value as any)}
                      className="w-4 h-4 text-purple-600"
                    />
                    <div>
                      <p className="font-medium text-gray-900">Yeni yayınlanacak</p>
                      <p className="text-sm text-gray-600">Bu şarkı ilk kez yayınlanacak</p>
                    </div>
                  </label>
                  {releaseStatus === 'new_release' && (
                    <div className="ml-7 space-y-2">
                      <label className="block text-sm font-medium text-gray-700">
                        Yayın Tarihi * (Min. 2 hafta sonrası)
                      </label>
                      <input
                        type="date"
                        value={newReleaseDate}
                        onChange={(e) => setNewReleaseDate(e.target.value)}
                        min={minDateString}
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                        required={releaseStatus === 'new_release'}
                      />
                      <p className="text-xs text-gray-500">
                        Şarkınızın platformlarda yayınlanması için en az 2 hafta önceden gönderilmelidir
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Track Information */}
            <div className="space-y-6">
              <div className="border-b border-gray-200 pb-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-xl font-semibold text-gray-900 flex items-center space-x-2">
                      <Music2 className="w-5 h-5 text-purple-600" />
                      <span>{getTrackTypeText()} Bilgileri</span>
                    </h2>
                    <p className="text-sm text-gray-600 mt-1">
                      {releaseType === 'single' 
                        ? 'Şarkınızın detay bilgilerini girin'
                        : `${tracks.length} parça için detay bilgilerini girin (${trackLimits.min}-${trackLimits.max} parça)`
                      }
                    </p>
                  </div>
                  <div className="flex items-center space-x-3">
                    <span className="text-sm text-gray-500">
                      {tracks.length} / {trackLimits.max} {getTrackTypeText().toLowerCase()}
                    </span>
                    {releaseType !== 'single' && (
                      <button
                        type="button"
                        onClick={addTrack}
                        disabled={!canAddTrack}
                        className="flex items-center space-x-2 px-4 py-2 bg-green-100 text-green-700 rounded-lg hover:bg-green-200 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        <Plus className="w-4 h-4" />
                        <span>{getTrackTypeText()} Ekle</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* Track Limit Info */}
              {releaseType !== 'single' && (
                <div className={`rounded-lg p-4 ${
                  tracks.length >= trackLimits.min && tracks.length <= trackLimits.max
                    ? 'bg-green-50 border border-green-200'
                    : 'bg-orange-50 border border-orange-200'
                }`}>
                  <div className="flex items-center space-x-2">
                    <span className={`text-sm font-medium ${
                      tracks.length >= trackLimits.min && tracks.length <= trackLimits.max
                        ? 'text-green-800'
                        : 'text-orange-800'
                    }`}>
                      {releaseType.toUpperCase()} Parça Limiti: {trackLimits.min}-{trackLimits.max} parça
                    </span>
                    <span className={`text-sm ${
                      tracks.length >= trackLimits.min && tracks.length <= trackLimits.max
                        ? 'text-green-600'
                        : 'text-orange-600'
                    }`}>
                      (Mevcut: {tracks.length})
                    </span>
                  </div>
                </div>
              )}

              {tracks.map((track, index) => (
                <div key={index} className="bg-gradient-to-r from-gray-50 to-blue-50 border border-gray-200 rounded-xl p-6">
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="text-lg font-semibold text-gray-900 flex items-center space-x-2">
                      <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-blue-500 rounded-lg flex items-center justify-center">
                        <span className="text-white font-bold text-sm">{index + 1}</span>
                      </div>
                      <span>
                        {getTrackTypeText()} {index + 1}
                        {releaseType === 'single' && ' (Ana Parça)'}
                      </span>
                    </h3>
                    {canRemoveTrack && releaseType !== 'single' && (
                      <button
                        type="button"
                        onClick={() => removeTrack(index)}
                        className="flex items-center space-x-1 px-3 py-1 bg-red-100 text-red-700 rounded-lg hover:bg-red-200 transition-colors"
                      >
                        <X className="w-4 h-4" />
                        <span>Kaldır</span>
                      </button>
                    )}
                  </div>

                  <div className="space-y-6">
                    {/* Track Name and Genre */}
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="block text-sm font-medium text-gray-700">
                          Parça Adı *
                        </label>
                        <input
                          type="text"
                          value={track.trackName}
                          onChange={(e) => updateTrack(index, 'trackName', e.target.value)}
                          className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                          placeholder="Şarkı adını girin"
                          required
                        />
                      </div>

                      <div className="space-y-2">
                        <label className="block text-sm font-medium text-gray-700">
                          Tür *
                        </label>
                        <select
                          value={track.genre}
                          onChange={(e) => updateTrack(index, 'genre', e.target.value)}
                          className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                          required
                        >
                          <option value="">Tür seçin</option>
                          <option value="pop">Pop</option>
                          <option value="rock">Rock</option>
                          <option value="hip-hop">Hip-Hop</option>
                          <option value="electronic">Elektronik</option>
                          <option value="folk">Folk</option>
                          <option value="jazz">Jazz</option>
                          <option value="classical">Klasik</option>
                          <option value="other">Diğer</option>
                        </select>
                      </div>
                    </div>

                    {/* File Link */}
                    <div className="space-y-2">
                      <label className="block text-sm font-medium text-gray-700">
                        Dosya Linki (WeTransfer/TransferNow) *
                      </label>
                      <input
                        type="url"
                        value={track.fileLink}
                        onChange={(e) => updateTrack(index, 'fileLink', e.target.value)}
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                        placeholder="https://wetransfer.com/downloads/..."
                        required
                      />
                      <p className="text-xs text-gray-500">
                        WAV formatında, 24-bit/44.1kHz kalitesinde yükleyin
                      </p>
                    </div>

                    {/* Additional Info */}
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      <div className="space-y-2">
                        <label className="block text-sm font-medium text-gray-700">
                          Söz Yazarı
                        </label>
                        <input
                          type="text"
                          value={track.songwriter}
                          onChange={(e) => updateTrack(index, 'songwriter', e.target.value)}
                          className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                          placeholder="Söz yazarı adı"
                        />
                      </div>

                      <div className="space-y-2">
                        <label className="block text-sm font-medium text-gray-700">
                          Besteci
                        </label>
                        <input
                          type="text"
                          value={track.composer}
                          onChange={(e) => updateTrack(index, 'composer', e.target.value)}
                          className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                          placeholder="Besteci adı"
                        />
                      </div>

                      <div className="space-y-2">
                        <label className="block text-sm font-medium text-gray-700">
                          Dil
                        </label>
                        <select
                          value={track.language}
                          onChange={(e) => updateTrack(index, 'language', e.target.value)}
                          className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                        >
                          <option value="tr">Türkçe</option>
                          <option value="en">İngilizce</option>
                          <option value="fr">Fransızca</option>
                          <option value="de">Almanca</option>
                          <option value="es">İspanyolca</option>
                          <option value="other">Diğer</option>
                        </select>
                      </div>
                    </div>

                    {/* Content Settings */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-3">
                        <label className="block text-sm font-medium text-gray-700">
                          Argo İçerik
                        </label>
                        <div className="flex space-x-6">
                          <label className="flex items-center space-x-2">
                            <input
                              type="radio"
                              name={`explicit-${index}`}
                              checked={!track.hasExplicitContent}
                              onChange={() => updateTrack(index, 'hasExplicitContent', false)}
                              className="w-4 h-4 text-purple-600"
                            />
                            <span className="text-sm text-gray-700">Temiz İçerik</span>
                          </label>
                          <label className="flex items-center space-x-2">
                            <input
                              type="radio"
                              name={`explicit-${index}`}
                              checked={track.hasExplicitContent}
                              onChange={() => updateTrack(index, 'hasExplicitContent', true)}
                              className="w-4 h-4 text-purple-600"
                            />
                            <span className="text-sm text-gray-700">Argo İçerik Var</span>
                          </label>
                        </div>
                      </div>

                      <div className="space-y-3">
                        <label className="block text-sm font-medium text-gray-700">
                          YouTube Content ID
                        </label>
                        <div className="flex space-x-6">
                          <label className="flex items-center space-x-2">
                            <input
                              type="radio"
                              name={`youtube-${index}`}
                              checked={!track.youtubeContentId}
                              onChange={() => updateTrack(index, 'youtubeContentId', false)}
                              className="w-4 h-4 text-purple-600"
                            />
                            <span className="text-sm text-gray-700">Talep Etme</span>
                          </label>
                          <label className="flex items-center space-x-2">
                            <input
                              type="radio"
                              name={`youtube-${index}`}
                              checked={track.youtubeContentId}
                              onChange={() => updateTrack(index, 'youtubeContentId', true)}
                              className="w-4 h-4 text-purple-600"
                            />
                            <span className="text-sm text-gray-700">Talep Et</span>
                          </label>
                        </div>
                        <p className="text-xs text-gray-500">
                          YouTube'da telif koruması için Content ID sistemi
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Submit Button */}
            <div className="pt-8 border-t border-gray-200">
              <div className="bg-gradient-to-r from-purple-50 to-blue-50 border border-purple-200 rounded-xl p-6 mb-6">
                <h3 className="font-semibold text-purple-900 mb-2">Gönderim Özeti</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                  <div>
                    <span className="text-purple-700">Yayın Türü:</span>
                    <p className="font-medium text-purple-900 capitalize">{releaseType}</p>
                  </div>
                  <div>
                    <span className="text-purple-700">Parça Sayısı:</span>
                    <p className="font-medium text-purple-900">{tracks.length} parça</p>
                  </div>
                  <div>
                    <span className="text-purple-700">Sanatçı Sayısı:</span>
                    <p className="font-medium text-purple-900">{selectedPrimaryArtists.length} birincil + {featuredArtists.filter(a => a.name).length} düet</p>
                  </div>
                </div>
              </div>

              <button
                type="submit"
                disabled={registeredArtists.length === 0 || tracks.length < trackLimits.min || tracks.length > trackLimits.max}
                className="w-full bg-gradient-to-r from-purple-500 to-blue-500 text-white font-semibold py-4 px-6 rounded-lg hover:from-purple-600 hover:to-blue-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 transition-all transform hover:scale-[1.02] disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
              >
                {registeredArtists.length === 0 
                  ? 'Önce Sanatçı Eklemelisiniz' 
                  : tracks.length < trackLimits.min || tracks.length > trackLimits.max
                    ? `${releaseType.toUpperCase()} için ${trackLimits.min}-${trackLimits.max} parça gerekli`
                    : releaseType === 'single' 
                      ? 'Şarkıyı Gönder' 
                      : `${releaseType.toUpperCase()} Gönder (${tracks.length} Parça)`
                }
              </button>
              
              {registeredArtists.length === 0 && (
                <p className="text-center text-sm text-red-600 mt-2">
                  Şarkı gönderebilmek için önce "Sanatçılar" bölümünden en az bir sanatçı eklemelisiniz.
                </p>
              )}
              
              {(tracks.length < trackLimits.min || tracks.length > trackLimits.max) && (
                <p className="text-center text-sm text-orange-600 mt-2">
                  {releaseType.toUpperCase()} için {trackLimits.min} ile {trackLimits.max} parça arasında olmalıdır.
                </p>
              )}
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default SubmitSong;