import React from 'react';
import { Music, Calendar, Check, Clock, X, Hash, Music2 } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useSongs } from '../contexts/SongContext';

const Catalog: React.FC = () => {
  const { user } = useAuth();
  const { getSongsByUser } = useSongs();

  if (!user) return null;

  const userSongs = getSongsByUser(user.id);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'distributed':
        return 'bg-green-100 text-green-800';
      case 'approved':
        return 'bg-blue-100 text-blue-800';
      case 'rejected':
        return 'bg-red-100 text-red-800';
      case 'review':
        return 'bg-orange-100 text-orange-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'distributed':
        return <Check className="w-4 h-4" />;
      case 'approved':
        return <Check className="w-4 h-4" />;
      case 'rejected':
        return <X className="w-4 h-4" />;
      case 'review':
        return <Clock className="w-4 h-4" />;
      default:
        return <Clock className="w-4 h-4" />;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'distributed':
        return 'Dağıtıldı';
      case 'approved':
        return 'Onaylandı';
      case 'rejected':
        return 'Reddedildi';
      case 'review':
        return 'İncelemede';
      default:
        return 'Bilinmiyor';
    }
  };

  const statusCounts = {
    total: userSongs.length,
    distributed: userSongs.filter(s => s.status === 'distributed').length,
    approved: userSongs.filter(s => s.status === 'approved').length,
    review: userSongs.filter(s => s.status === 'review').length,
    rejected: userSongs.filter(s => s.status === 'rejected').length
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-600 to-blue-600 rounded-2xl text-white p-8">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
            <Music className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-3xl font-bold">Müzik Kataloğum</h1>
            <p className="text-purple-100 mt-1">Tüm yayınlarınızı görüntüleyin ve takip edin</p>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Toplam Şarkı</p>
              <p className="text-2xl font-bold text-gray-900">{statusCounts.total}</p>
            </div>
            <Music className="w-8 h-8 text-purple-500" />
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">İncelemede</p>
              <p className="text-2xl font-bold text-orange-600">{statusCounts.review}</p>
            </div>
            <Clock className="w-8 h-8 text-orange-500" />
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Onaylanan</p>
              <p className="text-2xl font-bold text-blue-600">{statusCounts.approved}</p>
            </div>
            <Check className="w-8 h-8 text-blue-500" />
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Dağıtılan</p>
              <p className="text-2xl font-bold text-green-600">{statusCounts.distributed}</p>
            </div>
            <Check className="w-8 h-8 text-green-500" />
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Reddedilen</p>
              <p className="text-2xl font-bold text-red-600">{statusCounts.rejected}</p>
            </div>
            <X className="w-8 h-8 text-red-500" />
          </div>
        </div>
      </div>

      {/* Songs List */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">Şarkılarım</h2>
          <p className="text-gray-600 mt-1">
            {userSongs.length === 0 
              ? 'Henüz şarkı göndermediniz' 
              : `${userSongs.length} şarkı kayıtlı`
            }
          </p>
        </div>

        {userSongs.length === 0 ? (
          <div className="p-12 text-center">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Music className="w-8 h-8 text-gray-400" />
            </div>
            <p className="text-gray-600">Henüz şarkı göndermediniz</p>
            <p className="text-sm text-gray-500 mt-1">İlk şarkınızı göndererek başlayın</p>
            <a
              href="/submit"
              className="inline-flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-purple-500 to-blue-500 text-white rounded-lg hover:from-purple-600 hover:to-blue-600 transition-all mt-4"
            >
              <Music className="w-5 h-5" />
              <span>İlk Şarkınızı Gönderin</span>
            </a>
          </div>
        ) : (
          <div className="divide-y divide-gray-200">
            {userSongs.map((song) => (
              <div key={song.id} className="p-6 hover:bg-gray-50 transition-colors">
                <div className="flex items-center space-x-4">
                  {/* Music Note Icon instead of Cover Art */}
                  <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-blue-500 rounded-lg flex items-center justify-center shadow-sm">
                    <Music2 className="w-8 h-8 text-white" />
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900">{song.title}</h3>
                        <p className="text-gray-600">{song.artist}</p>
                        <div className="flex items-center space-x-4 mt-2 text-sm text-gray-500">
                          <span className="flex items-center space-x-1">
                            <Hash className="w-4 h-4" />
                            <span className="font-mono">{song.releaseCode}</span>
                          </span>
                          <span className="capitalize">{song.genre}</span>
                          <span className="capitalize">{song.releaseType}</span>
                        </div>
                      </div>
                      
                      <div className="text-right">
                        <div className={`inline-flex items-center space-x-1 px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(song.status)}`}>
                          {getStatusIcon(song.status)}
                          <span>{getStatusText(song.status)}</span>
                        </div>
                        <div className="flex items-center space-x-1 mt-2 text-sm text-gray-500">
                          <Calendar className="w-4 h-4" />
                          <span>Yayın: {new Date(song.releaseDate).toLocaleDateString('tr-TR')}</span>
                        </div>
                        <div className="text-xs text-gray-400 mt-1">
                          Gönderim: {new Date(song.submittedDate).toLocaleDateString('tr-TR')}
                        </div>
                      </div>
                    </div>
                    
                    {/* Primary Artists */}
                    {song.primaryArtists.length > 0 && (
                      <div className="mt-3">
                        <p className="text-xs text-gray-500 mb-1">Birincil Sanatçılar:</p>
                        <div className="flex flex-wrap gap-1">
                          {song.primaryArtists.map((artist, index) => (
                            <span
                              key={index}
                              className="px-2 py-1 bg-blue-100 text-blue-800 rounded-md text-xs"
                            >
                              {artist.name}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Featured Artists */}
                    {song.featuredArtists.length > 0 && (
                      <div className="mt-2">
                        <p className="text-xs text-gray-500 mb-1">Düet Sanatçıları:</p>
                        <div className="flex flex-wrap gap-1">
                          {song.featuredArtists.map((artist, index) => (
                            <span
                              key={index}
                              className="px-2 py-1 bg-purple-100 text-purple-800 rounded-md text-xs"
                            >
                              {artist.name}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Rejection Reason */}
                    {song.status === 'rejected' && song.rejectionReason && (
                      <div className="mt-3 p-3 bg-red-50 border border-red-200 rounded-lg">
                        <p className="text-sm text-red-800">
                          <strong>Red Sebebi:</strong> {song.rejectionReason}
                        </p>
                      </div>
                    )}

                    {/* Additional Info */}
                    <div className="mt-3 flex items-center space-x-4 text-xs">
                      <span className={`px-2 py-1 rounded-md ${song.hasExplicitContent ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'}`}>
                        {song.hasExplicitContent ? 'Argo İçerik' : 'Temiz İçerik'}
                      </span>
                      <span className={`px-2 py-1 rounded-md ${song.youtubeContentId ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'}`}>
                        {song.youtubeContentId ? 'YouTube ID' : 'YouTube ID Yok'}
                      </span>
                      <span className="px-2 py-1 bg-gray-100 text-gray-800 rounded-md">
                        {song.language.toUpperCase()}
                      </span>
                      {song.isrcCode && (
                        <span className="px-2 py-1 bg-gray-100 text-gray-800 rounded-md font-mono">
                          {song.isrcCode}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Release Code Info */}
      <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
        <div className="flex items-start space-x-3">
          <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
            <Hash className="w-4 h-4 text-white" />
          </div>
          <div>
            <h3 className="font-semibold text-blue-900 mb-2">Yayın Kodları Hakkında</h3>
            <ul className="text-sm text-blue-800 space-y-1 list-disc ml-4">
              <li>Her şarkınız için benzersiz bir yayın kodu otomatik olarak oluşturulur.</li>
              <li>Yayın kodları SCR + yıl + 4 haneli numara formatındadır (örn: SCR202400001).</li>
              <li>Bu kodlar ile şarkılarınızı kolayca takip edebilirsiniz.</li>
              <li>Yayın kodları değiştirilemez ve her şarkı için benzersizdir.</li>
              <li>Destek taleplerinizde yayın kodunu belirtmeniz işlemleri hızlandırır.</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Catalog;