import React, { useState } from 'react';
import { Plus, User, ExternalLink, AlertCircle, Mail } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { PACKAGE_LIMITS } from '../types';

interface Artist {
  id: string;
  name: string;
  spotifyLink: string;
  appleMusicLink: string;
}

const Artists: React.FC = () => {
  const { user } = useAuth();
  const [artists, setArtists] = useState<Artist[]>(() => {
    // Load user-specific artists from localStorage
    if (!user) return [];
    const savedArtists = localStorage.getItem(`artists_${user.id}`);
    return savedArtists ? JSON.parse(savedArtists) : [];
  });
  const [showAddForm, setShowAddForm] = useState(false);
  const [newArtist, setNewArtist] = useState({
    name: '',
    spotifyLink: '',
    appleMusicLink: ''
  });

  if (!user) return null;

  // Save artists to user-specific localStorage
  const saveArtists = (updatedArtists: Artist[]) => {
    setArtists(updatedArtists);
    localStorage.setItem(`artists_${user.id}`, JSON.stringify(updatedArtists));
  };

  const canAddArtist = artists.length < PACKAGE_LIMITS[user.package];
  const remainingSlots = PACKAGE_LIMITS[user.package] - artists.length;

  const handleAddArtist = (e: React.FormEvent) => {
    e.preventDefault();
    if (!canAddArtist) {
      alert('Sanatçı limitinize ulaştınız. Daha fazla sanatçı eklemek için Scarp Music ile iletişime geçin.');
      return;
    }

    const artist: Artist = {
      id: Date.now().toString(),
      ...newArtist
    };

    saveArtists([...artists, artist]);
    setNewArtist({ name: '', spotifyLink: '', appleMusicLink: '' });
    setShowAddForm(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl text-white p-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
              <User className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">Sanatçılarım</h1>
              <p className="text-blue-100 mt-1">Birincil sanatçılarınızı yönetin</p>
            </div>
          </div>
          
          <div className="text-right">
            <p className="text-blue-100">Paket Limiti</p>
            <p className="text-2xl font-bold">
              {artists.length}/{PACKAGE_LIMITS[user.package] === 999 ? '∞' : PACKAGE_LIMITS[user.package]}
            </p>
          </div>
        </div>
      </div>

      {/* Package Info */}
      <div className={`rounded-xl p-6 ${
        canAddArtist 
          ? 'bg-green-50 border border-green-200' 
          : 'bg-red-50 border border-red-200'
      }`}>
        <div className="flex items-start space-x-3">
          <AlertCircle className={`w-6 h-6 mt-1 ${
            canAddArtist ? 'text-green-600' : 'text-red-600'
          }`} />
          <div>
            <h3 className={`font-semibold ${
              canAddArtist ? 'text-green-900' : 'text-red-900'
            }`}>
              {canAddArtist ? 'Sanatçı Ekleyebilirsiniz' : 'Sanatçı Limiti Doldu'}
            </h3>
            <p className={`text-sm mt-1 ${
              canAddArtist ? 'text-green-700' : 'text-red-700'
            }`}>
              {canAddArtist 
                ? `${remainingSlots} adet daha sanatçı ekleyebilirsiniz.`
                : 'Daha fazla sanatçı eklemek için Scarp Music ile iletişime geçin.'
              }
            </p>
            {!canAddArtist && (
              <div className="mt-3">
                <a
                  href="mailto:scarpdistro@gmail.com"
                  className="inline-flex items-center space-x-2 px-4 py-2 bg-red-100 hover:bg-red-200 text-red-800 rounded-lg transition-colors text-sm"
                >
                  <span>İletişime Geç</span>
                  <ExternalLink className="w-4 h-4" />
                </a>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Add Artist Button */}
      {canAddArtist && !showAddForm && (
        <div className="text-center">
          <button
            onClick={() => setShowAddForm(true)}
            className="inline-flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-500 text-white rounded-lg hover:from-blue-600 hover:to-purple-600 transition-all transform hover:scale-105"
          >
            <Plus className="w-5 h-5" />
            <span>Yeni Sanatçı Ekle</span>
          </button>
        </div>
      )}

      {/* Add Artist Form */}
      {showAddForm && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Yeni Sanatçı Ekle</h2>
          
          <form onSubmit={handleAddArtist} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Sanatçı Adı *
              </label>
              <input
                type="text"
                value={newArtist.name}
                onChange={(e) => setNewArtist({ ...newArtist, name: e.target.value })}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Sanatçı adını girin"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Spotify Profil Linki
              </label>
              <input
                type="url"
                value={newArtist.spotifyLink}
                onChange={(e) => setNewArtist({ ...newArtist, spotifyLink: e.target.value })}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="https://open.spotify.com/artist/..."
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Apple Music Profil Linki
              </label>
              <input
                type="url"
                value={newArtist.appleMusicLink}
                onChange={(e) => setNewArtist({ ...newArtist, appleMusicLink: e.target.value })}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="https://music.apple.com/artist/..."
              />
            </div>

            <div className="flex space-x-4">
              <button
                type="submit"
                className="flex-1 bg-gradient-to-r from-blue-500 to-purple-500 text-white py-3 px-6 rounded-lg hover:from-blue-600 hover:to-purple-600 transition-all"
              >
                Sanatçıyı Ekle
              </button>
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="flex-1 bg-gray-100 text-gray-700 py-3 px-6 rounded-lg hover:bg-gray-200 transition-colors"
              >
                İptal
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Artists List */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">Kayıtlı Sanatçılar</h2>
          <p className="text-gray-600 mt-1">
            {artists.length === 0 
              ? 'Henüz sanatçı eklenmemiş' 
              : `${artists.length} sanatçı kayıtlı`
            }
          </p>
        </div>

        {artists.length === 0 ? (
          <div className="p-12 text-center">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <User className="w-8 h-8 text-gray-400" />
            </div>
            <p className="text-gray-600">Henüz sanatçı eklenmemiş</p>
            <p className="text-sm text-gray-500 mt-1">İlk sanatçınızı ekleyerek başlayın</p>
          </div>
        ) : (
          <div className="divide-y divide-gray-200">
            {artists.map((artist, index) => (
              <div key={artist.id} className="p-6">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-500 rounded-lg flex items-center justify-center">
                    <User className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-gray-900">{artist.name}</h3>
                    <p className="text-sm text-gray-500">Birincil Sanatçı #{index + 1}</p>
                    
                    {/* Artist Links */}
                    {(artist.spotifyLink || artist.appleMusicLink) && (
                      <div className="flex space-x-2 mt-2">
                        {artist.spotifyLink && (
                          <a
                            href={artist.spotifyLink}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center space-x-1 px-2 py-1 bg-green-100 text-green-800 rounded-md text-xs hover:bg-green-200 transition-colors"
                          >
                            <ExternalLink className="w-3 h-3" />
                            <span>Spotify</span>
                          </a>
                        )}
                        {artist.appleMusicLink && (
                          <a
                            href={artist.appleMusicLink}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center space-x-1 px-2 py-1 bg-gray-100 text-gray-800 rounded-md text-xs hover:bg-gray-200 transition-colors"
                          >
                            <ExternalLink className="w-3 h-3" />
                            <span>Apple Music</span>
                          </a>
                        )}
                      </div>
                    )}
                  </div>
                  <div className="text-right">
                    <span className="inline-flex items-center px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-medium">
                      Aktif
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Important Information */}
      <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
        <div className="flex items-start space-x-3">
          <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
            <span className="text-white text-xs font-bold">!</span>
          </div>
          <div>
            <h3 className="font-semibold text-blue-900 mb-2">Önemli Bilgiler</h3>
            <ul className="text-sm text-blue-800 space-y-1 list-disc ml-4">
              <li>Bir kez eklenen sanatçılar düzenlenemez veya silinemez.</li>
              <li>Şarkı gönderim formunda bu sanatçılar otomatik olarak seçilebilir olacaktır.</li>
              <li>Düet sanatçıları (ft.) için bu sistemi kullanmanıza gerek yoktur.</li>
              <li>Sanatçı bilgileri (Spotify/Apple Music linkleri) sistem tarafından güvenli şekilde saklanır.</li>
              <li>Paket yükseltmesi için müşteri temsilcinizle iletişime geçin.</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Contact Information */}
      <div className="bg-orange-50 border border-orange-200 rounded-xl p-6">
        <div className="flex items-start space-x-3">
          <div className="w-6 h-6 bg-orange-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
            <span className="text-white text-xs font-bold">📞</span>
          </div>
          <div>
            <h3 className="font-semibold text-orange-900 mb-2">Destek İhtiyacınız mı Var?</h3>
            <p className="text-sm text-orange-800 mb-3">
              Sanatçı bilgilerinde değişiklik yapmak veya paket yükseltmesi için temsilcinizle iletişime geçin.
            </p>
            <div className="flex flex-wrap gap-3">
              <a
                href="mailto:scarpdistro@gmail.com"
                className="inline-flex items-center space-x-2 px-4 py-2 bg-orange-100 hover:bg-orange-200 text-orange-800 rounded-lg transition-colors text-sm"
              >
                <Mail className="w-4 h-4" />
                <span>E-posta Gönder</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Artists;