import React from 'react';
import { Users, FileText, DollarSign, TrendingUp, Clock, CheckCircle, AlertTriangle, Music, Settings, Shield, User } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useSongs } from '../contexts/SongContext';
import { useNotifications } from '../contexts/NotificationContext';
import StatCard from '../components/Dashboard/StatCard';

const AdminDashboard: React.FC = () => {
  const { getAllUsers } = useAuth();
  const { songs } = useSongs();
  const { notifications } = useNotifications();

  const allUsers = getAllUsers();
  const artistUsers = allUsers.filter(user => user.role === 'artist');

  // Calculate total artists from all users
  const totalArtists = artistUsers.reduce((sum, user) => {
    const savedArtists = localStorage.getItem(`artists_${user.id}`);
    const userArtists = savedArtists ? JSON.parse(savedArtists) : [];
    return sum + userArtists.length;
  }, 0);

  // Real statistics from actual data
  const adminStats = {
    totalUsers: allUsers.length,
    activeUsers: allUsers.filter(user => user.role === 'artist').length,
    adminUsers: allUsers.filter(user => user.role === 'admin').length,
    totalArtists: totalArtists,
    totalSongs: songs.length,
    pendingReviews: songs.filter(s => s.status === 'review').length,
    approvedSongs: songs.filter(s => s.status === 'approved').length,
    distributedSongs: songs.filter(s => s.status === 'distributed').length,
    rejectedSongs: songs.filter(s => s.status === 'rejected').length,
    totalRevenue: artistUsers.reduce((sum, user) => sum + user.totalEarnings, 0),
    totalNotifications: notifications.length,
    unreadNotifications: notifications.filter(n => n.unread).length
  };

  // Recent activities based on actual data
  const recentActivity = [
    ...songs.slice(-5).map(song => ({
      action: `Yeni şarkı: ${song.title}`,
      user: song.username,
      time: `${Math.floor((Date.now() - new Date(song.submittedDate).getTime()) / (1000 * 60 * 60 * 24))} gün önce`,
      type: 'submission',
      status: song.status
    })),
    ...allUsers.slice(-3).filter(user => user.role === 'artist').map(user => ({
      action: 'Yeni kullanıcı kaydı',
      user: user.username,
      time: 'Yakın zamanda',
      type: 'user',
      status: 'active'
    }))
  ].slice(0, 8);

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'user':
        return '👤';
      case 'submission':
        return '📤';
      case 'approval':
        return '✅';
      case 'rejection':
        return '❌';
      case 'distribution':
        return '🚀';
      default:
        return '📋';
    }
  };

  const getActivityColor = (type: string) => {
    switch (type) {
      case 'user':
        return 'bg-blue-50 border-blue-200';
      case 'submission':
        return 'bg-purple-50 border-purple-200';
      case 'approval':
        return 'bg-green-50 border-green-200';
      case 'rejection':
        return 'bg-red-50 border-red-200';
      case 'distribution':
        return 'bg-indigo-50 border-indigo-200';
      default:
        return 'bg-gray-50 border-gray-200';
    }
  };

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-slate-800 to-slate-900 rounded-2xl text-white p-8">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
            <Shield className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-3xl font-bold">Admin Kontrol Paneli</h1>
            <p className="text-slate-200 text-lg mt-1">
              Scarp Music platformunu yönetin ve denetleyin
            </p>
          </div>
        </div>
      </div>

      {/* System Status Alert */}
      <div className="bg-green-50 border border-green-200 rounded-xl p-6">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
            <CheckCircle className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-semibold text-green-900">Sistem Durumu: Çevrimiçi</h3>
            <p className="text-sm text-green-800 mt-1">
              Tüm sistemler normal çalışıyor. Son güncelleme: {new Date().toLocaleDateString('tr-TR')}
            </p>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        <StatCard
          title="Toplam Kullanıcı"
          value={adminStats.totalUsers.toString()}
          subtitle={`${adminStats.activeUsers} sanatçı, ${adminStats.adminUsers} admin`}
          icon={Users}
          color="blue"
        />
        
        <StatCard
          title="Toplam Sanatçı"
          value={adminStats.totalArtists.toString()}
          subtitle="Kayıtlı sanatçı"
          icon={User}
          color="purple"
        />
        
        <StatCard
          title="Toplam Şarkı"
          value={adminStats.totalSongs.toString()}
          subtitle="Sistemde kayıtlı"
          icon={Music}
          color="purple"
        />
        
        <StatCard
          title="İnceleme Bekleyen"
          value={adminStats.pendingReviews.toString()}
          subtitle="Acil işlem gerekli"
          icon={Clock}
          color="orange"
        />
        
        <StatCard
          title="Onaylanan Şarkı"
          value={adminStats.approvedSongs.toString()}
          subtitle="Dağıtıma hazır"
          icon={CheckCircle}
          color="green"
        />
        
        <StatCard
          title="Dağıtılan Şarkı"
          value={adminStats.distributedSongs.toString()}
          subtitle="Platformlarda yayında"
          icon={TrendingUp}
          color="blue"
        />
        
        <StatCard
          title="Platform Geliri"
          value={`₺${adminStats.totalRevenue.toLocaleString('tr-TR')}`}
          subtitle="Toplam sanatçı kazancı"
          icon={DollarSign}
          color="green"
        />
        
        <StatCard
          title="Sistem Bildirimleri"
          value={adminStats.totalNotifications.toString()}
          subtitle={`${adminStats.unreadNotifications} okunmamış`}
          icon={AlertTriangle}
          color="orange"
        />
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <a
          href="/admin/users"
          className="bg-white rounded-xl p-6 shadow-sm border border-gray-200 hover:shadow-md transition-shadow cursor-pointer group"
        >
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center group-hover:bg-blue-200 transition-colors">
              <Users className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <h3 className="font-semibold text-gray-900">Kullanıcı Yönetimi</h3>
              <p className="text-sm text-gray-600">Hesapları yönet</p>
            </div>
          </div>
        </a>

        <a
          href="/admin/songs"
          className="bg-white rounded-xl p-6 shadow-sm border border-gray-200 hover:shadow-md transition-shadow cursor-pointer group"
        >
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center group-hover:bg-purple-200 transition-colors">
              <FileText className="w-5 h-5 text-purple-600" />
            </div>
            <div>
              <h3 className="font-semibold text-gray-900">Şarkı İncelemesi</h3>
              <p className="text-sm text-gray-600">{adminStats.pendingReviews} bekliyor</p>
            </div>
          </div>
        </a>

        <a
          href="/admin/finance"
          className="bg-white rounded-xl p-6 shadow-sm border border-gray-200 hover:shadow-md transition-shadow cursor-pointer group"
        >
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center group-hover:bg-green-200 transition-colors">
              <DollarSign className="w-5 h-5 text-green-600" />
            </div>
            <div>
              <h3 className="font-semibold text-gray-900">Finans Yönetimi</h3>
              <p className="text-sm text-gray-600">Gelir ve çekimler</p>
            </div>
          </div>
        </a>

        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200 hover:shadow-md transition-shadow cursor-pointer group">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center group-hover:bg-gray-200 transition-colors">
              <Settings className="w-5 h-5 text-gray-600" />
            </div>
            <div>
              <h3 className="font-semibold text-gray-900">Sistem Ayarları</h3>
              <p className="text-sm text-gray-600">Platform yapılandırması</p>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-6">Son Sistem Aktiviteleri</h2>
        
        {recentActivity.length === 0 ? (
          <div className="text-center py-8">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <TrendingUp className="w-8 h-8 text-gray-400" />
            </div>
            <p className="text-gray-600">Henüz sistem aktivitesi bulunmuyor</p>
          </div>
        ) : (
          <div className="space-y-4">
            {recentActivity.map((activity, index) => (
              <div key={index} className={`flex items-center justify-between p-4 rounded-lg border ${getActivityColor(activity.type)}`}>
                <div className="flex items-center space-x-3">
                  <div className="text-xl">
                    {getActivityIcon(activity.type)}
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">{activity.action}</p>
                    <p className="text-sm text-gray-600">
                      Kullanıcı: {activity.user}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-sm text-gray-500">{activity.time}</span>
                  {activity.status && (
                    <div className="mt-1">
                      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                        activity.status === 'review' ? 'bg-orange-100 text-orange-800' :
                        activity.status === 'approved' ? 'bg-green-100 text-green-800' :
                        activity.status === 'distributed' ? 'bg-blue-100 text-blue-800' :
                        activity.status === 'rejected' ? 'bg-red-100 text-red-800' :
                        'bg-gray-100 text-gray-800'
                      }`}>
                        {activity.status === 'review' ? 'İncelemede' :
                         activity.status === 'approved' ? 'Onaylandı' :
                         activity.status === 'distributed' ? 'Dağıtıldı' :
                         activity.status === 'rejected' ? 'Reddedildi' :
                         'Aktif'}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* System Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Platform İstatistikleri</h3>
          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-600">Şarkı Onay Oranı</span>
                <span className="text-sm font-medium text-gray-900">
                  {adminStats.totalSongs > 0 
                    ? Math.round(((adminStats.approvedSongs + adminStats.distributedSongs) / adminStats.totalSongs) * 100)
                    : 0}%
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-green-500 h-2 rounded-full" 
                  style={{ 
                    width: `${adminStats.totalSongs > 0 
                      ? ((adminStats.approvedSongs + adminStats.distributedSongs) / adminStats.totalSongs) * 100
                      : 0}%` 
                  }}
                ></div>
              </div>
            </div>
            
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-600">Aktif Kullanıcı Oranı</span>
                <span className="text-sm font-medium text-gray-900">
                  {adminStats.totalUsers > 0 
                    ? Math.round((adminStats.activeUsers / adminStats.totalUsers) * 100)
                    : 0}%
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-blue-500 h-2 rounded-full" 
                  style={{ 
                    width: `${adminStats.totalUsers > 0 
                      ? (adminStats.activeUsers / adminStats.totalUsers) * 100
                      : 0}%` 
                  }}
                ></div>
              </div>
            </div>
            
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-600">Dağıtım Başarı Oranı</span>
                <span className="text-sm font-medium text-gray-900">
                  {adminStats.approvedSongs > 0 
                    ? Math.round((adminStats.distributedSongs / adminStats.approvedSongs) * 100)
                    : 0}%
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-purple-500 h-2 rounded-full" 
                  style={{ 
                    width: `${adminStats.approvedSongs > 0 
                      ? (adminStats.distributedSongs / adminStats.approvedSongs) * 100
                      : 0}%` 
                  }}
                ></div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Sistem Durumu</h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Platform Durumu</span>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span className="text-sm text-green-600 font-medium">Çevrimiçi</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Veritabanı</span>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span className="text-sm text-green-600 font-medium">Stabil</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Dağıtım Servisleri</span>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span className="text-sm text-green-600 font-medium">Aktif</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Bildirim Sistemi</span>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span className="text-sm text-green-600 font-medium">Çalışıyor</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Ödeme Sistemi</span>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span className="text-sm text-green-600 font-medium">Güvenli</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Admin Actions */}
      <div className="bg-slate-50 border border-slate-200 rounded-xl p-6">
        <div className="flex items-center space-x-3 mb-4">
          <div className="w-8 h-8 bg-slate-600 rounded-full flex items-center justify-center">
            <Shield className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-semibold text-slate-900">Admin Yetkileri</h3>
            <p className="text-sm text-slate-600">Platform yönetimi için mevcut işlemler</p>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white border border-slate-200 rounded-lg p-4">
            <h4 className="font-medium text-slate-900 mb-2">Kullanıcı İşlemleri</h4>
            <ul className="text-sm text-slate-600 space-y-1">
              <li>• Yeni kullanıcı oluşturma</li>
              <li>• Hesap durumu değiştirme</li>
              <li>• Paket yükseltme/düşürme</li>
              <li>• Kullanıcı verilerini düzenleme</li>
            </ul>
          </div>
          
          <div className="bg-white border border-slate-200 rounded-lg p-4">
            <h4 className="font-medium text-slate-900 mb-2">İçerik Yönetimi</h4>
            <ul className="text-sm text-slate-600 space-y-1">
              <li>• Şarkı onaylama/reddetme</li>
              <li>• Dağıtım başlatma</li>
              <li>• Kalite kontrol</li>
              <li>• İçerik moderasyonu</li>
            </ul>
          </div>
          
          <div className="bg-white border border-slate-200 rounded-lg p-4">
            <h4 className="font-medium text-slate-900 mb-2">Finansal İşlemler</h4>
            <ul className="text-sm text-slate-600 space-y-1">
              <li>• Para çekim onayları</li>
              <li>• Gelir verisi ekleme</li>
              <li>• Finansal rapor oluşturma</li>
              <li>• Ödeme takibi</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;