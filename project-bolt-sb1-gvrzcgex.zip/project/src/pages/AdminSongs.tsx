import React, { useState } from 'react';
import { FileText, Search, Filter, Eye, Check, X, Clock, Music, Calendar, User, ExternalLink, Hash } from 'lucide-react';
import { useSongs } from '../contexts/SongContext';
import { useNotifications } from '../contexts/NotificationContext';

const AdminSongs: React.FC = () => {
  const { songs, updateSongStatus } = useSongs();
  const { addNotification } = useNotifications();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterGenre, setFilterGenre] = useState<string>('all');
  const [selectedSong, setSelectedSong] = useState<any>(null);
  const [showSongModal, setShowSongModal] = useState(false);
  const [rejectionReason, setRejectionReason] = useState('');

  const filteredSongs = songs.filter(song => {
    const matchesSearch = song.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         song.artist.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         song.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         song.releaseCode.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === 'all' || song.status === filterStatus;
    const matchesGenre = filterGenre === 'all' || song.genre.toLowerCase() === filterGenre.toLowerCase();
    
    return matchesSearch && matchesStatus && matchesGenre;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'review':
        return 'bg-orange-100 text-orange-800';
      case 'approved':
        return 'bg-blue-100 text-blue-800';
      case 'rejected':
        return 'bg-red-100 text-red-800';
      case 'distributed':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'review':
        return 'İncelemede';
      case 'approved':
        return 'Onaylandı';
      case 'rejected':
        return 'Reddedildi';
      case 'distributed':
        return 'Dağıtıldı';
      default:
        return 'Bilinmiyor';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'review':
        return <Clock className="w-4 h-4" />;
      case 'approved':
        return <Check className="w-4 h-4" />;
      case 'rejected':
        return <X className="w-4 h-4" />;
      case 'distributed':
        return <Check className="w-4 h-4" />;
      default:
        return <Clock className="w-4 h-4" />;
    }
  };

  const handleSongAction = (action: string, songId: string, reason?: string) => {
    const song = songs.find(s => s.id === songId);
    if (!song) return;

    let newStatus: any;
    let notificationTitle = '';
    let notificationMessage = '';
    let notificationType: 'success' | 'warning' | 'info' | 'error' = 'info';

    switch (action) {
      case 'approve':
        newStatus = 'approved';
        notificationTitle = '🎉 Şarkınız Onaylandı!';
        notificationMessage = `"${song.title}" adlı şarkınız inceleme sürecini başarıyla tamamladı ve onaylandı. Artık dağıtım için hazır!`;
        notificationType = 'success';
        updateSongStatus(songId, 'approved');
        break;
      case 'reject':
        newStatus = 'rejected';
        notificationTitle = '❌ Şarkınız Reddedildi';
        notificationMessage = reason 
          ? `"${song.title}" adlı şarkınız reddedildi. Sebep: ${reason}`
          : `"${song.title}" adlı şarkınız inceleme sürecinde reddedildi. Lütfen temsilcinizle iletişime geçin.`;
        notificationType = 'error';
        updateSongStatus(songId, 'rejected', reason);
        break;
      case 'distribute':
        newStatus = 'distributed';
        notificationTitle = '🚀 Şarkınız Dağıtıldı!';
        notificationMessage = `"${song.title}" adlı şarkınız tüm dijital platformlarda yayınlandı! Artık dinleyicileriniz şarkınızı bulabilir.`;
        notificationType = 'success';
        updateSongStatus(songId, 'distributed');
        break;
    }

    // Send notification to user
    addNotification({
      userId: song.userId,
      title: notificationTitle,
      message: notificationMessage,
      type: notificationType,
      relatedSongId: songId,
      relatedSongTitle: song.title,
      actionType: action === 'approve' ? 'song_approved' : 
                  action === 'reject' ? 'song_rejected' : 
                  action === 'distribute' ? 'song_distributed' : 'general'
    });

    setShowSongModal(false);
    setRejectionReason('');
  };

  const totalStats = {
    totalSongs: songs.length,
    pendingReview: songs.filter(s => s.status === 'review').length,
    approved: songs.filter(s => s.status === 'approved').length,
    distributed: songs.filter(s => s.status === 'distributed').length,
    rejected: songs.filter(s => s.status === 'rejected').length
  };

  const genres = [...new Set(songs.map(song => song.genre))];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-600 to-indigo-600 rounded-2xl text-white p-8">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
            <FileText className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-3xl font-bold">Şarkı İncelemesi</h1>
            <p className="text-purple-100 mt-1">Gönderilen şarkıları inceleyin ve onaylayın</p>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Toplam Şarkı</p>
              <p className="text-2xl font-bold text-gray-900">{totalStats.totalSongs}</p>
            </div>
            <Music className="w-8 h-8 text-purple-500" />
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">İncelemede</p>
              <p className="text-2xl font-bold text-orange-600">{totalStats.pendingReview}</p>
            </div>
            <Clock className="w-8 h-8 text-orange-500" />
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Onaylanan</p>
              <p className="text-2xl font-bold text-blue-600">{totalStats.approved}</p>
            </div>
            <Check className="w-8 h-8 text-blue-500" />
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Dağıtılan</p>
              <p className="text-2xl font-bold text-green-600">{totalStats.distributed}</p>
            </div>
            <Check className="w-8 h-8 text-green-500" />
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Reddedilen</p>
              <p className="text-2xl font-bold text-red-600">{totalStats.rejected}</p>
            </div>
            <X className="w-8 h-8 text-red-500" />
          </div>
        </div>
      </div>

      {/* Filters and Search */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
          <div className="flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Şarkı, sanatçı, kullanıcı veya yayın kodu ara..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent w-80"
              />
            </div>

            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            >
              <option value="all">Tüm Durumlar</option>
              <option value="review">İncelemede</option>
              <option value="approved">Onaylandı</option>
              <option value="rejected">Reddedildi</option>
              <option value="distributed">Dağıtıldı</option>
            </select>

            <select
              value={filterGenre}
              onChange={(e) => setFilterGenre(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            >
              <option value="all">Tüm Türler</option>
              {genres.map(genre => (
                <option key={genre} value={genre}>{genre}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Songs List */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">
            Şarkılar ({filteredSongs.length})
          </h2>
        </div>

        {filteredSongs.length === 0 ? (
          <div className="p-12 text-center">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Music className="w-8 h-8 text-gray-400" />
            </div>
            <p className="text-gray-600">Henüz şarkı gönderilmemiş</p>
            <p className="text-sm text-gray-500 mt-1">
              Kullanıcılar şarkı gönderdiğinde burada görünecektir
            </p>
          </div>
        ) : (
          <div className="divide-y divide-gray-200">
            {filteredSongs.map((song) => (
              <div key={song.id} className="p-6 hover:bg-gray-50 transition-colors">
                <div className="flex items-center space-x-4">
                  <img
                    src={song.albumCover}
                    alt={song.title}
                    className="w-16 h-16 rounded-lg object-cover shadow-sm"
                  />
                  
                  <div className="flex-1">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900">{song.title}</h3>
                        <p className="text-gray-600">{song.artist}</p>
                        <div className="flex items-center space-x-4 mt-2 text-sm text-gray-500">
                          <span className="flex items-center space-x-1">
                            <User className="w-4 h-4" />
                            <span>{song.username}</span>
                          </span>
                          <span className="flex items-center space-x-1">
                            <Hash className="w-4 h-4" />
                            <span className="font-mono">{song.releaseCode}</span>
                          </span>
                          <span className="flex items-center space-x-1">
                            <Calendar className="w-4 h-4" />
                            <span>{new Date(song.submittedDate).toLocaleDateString('tr-TR')}</span>
                          </span>
                          <span className="capitalize">{song.genre}</span>
                          <span className="capitalize">{song.releaseType}</span>
                        </div>
                      </div>
                      
                      <div className="text-right">
                        <div className={`inline-flex items-center space-x-1 px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(song.status)}`}>
                          {getStatusIcon(song.status)}
                          <span>{getStatusText(song.status)}</span>
                        </div>
                        <div className="mt-2 text-sm text-gray-500">
                          Yayın: {new Date(song.releaseDate).toLocaleDateString('tr-TR')}
                        </div>
                      </div>
                    </div>
                    
                    <div className="mt-4 flex items-center justify-between">
                      <div className="flex items-center space-x-4 text-sm">
                        <span className={`px-2 py-1 rounded-md ${song.hasExplicitContent ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'}`}>
                          {song.hasExplicitContent ? 'Argo İçerik' : 'Temiz İçerik'}
                        </span>
                        <span className={`px-2 py-1 rounded-md ${song.youtubeContentId ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'}`}>
                          {song.youtubeContentId ? 'YouTube ID' : 'YouTube ID Yok'}
                        </span>
                        <span className="px-2 py-1 bg-gray-100 text-gray-800 rounded-md">
                          {song.language.toUpperCase()}
                        </span>
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => {
                            setSelectedSong(song);
                            setShowSongModal(true);
                          }}
                          className="flex items-center space-x-1 px-3 py-1 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200 transition-colors"
                        >
                          <Eye className="w-4 h-4" />
                          <span>Detay</span>
                        </button>
                        
                        {song.status === 'review' && (
                          <>
                            <button
                              onClick={() => handleSongAction('approve', song.id)}
                              className="flex items-center space-x-1 px-3 py-1 bg-green-100 text-green-700 rounded-lg hover:bg-green-200 transition-colors"
                            >
                              <Check className="w-4 h-4" />
                              <span>Onayla</span>
                            </button>
                            <button
                              onClick={() => {
                                setSelectedSong(song);
                                setShowSongModal(true);
                              }}
                              className="flex items-center space-x-1 px-3 py-1 bg-red-100 text-red-700 rounded-lg hover:bg-red-200 transition-colors"
                            >
                              <X className="w-4 h-4" />
                              <span>Reddet</span>
                            </button>
                          </>
                        )}
                        
                        {song.status === 'approved' && (
                          <button
                            onClick={() => handleSongAction('distribute', song.id)}
                            className="flex items-center space-x-1 px-3 py-1 bg-purple-100 text-purple-700 rounded-lg hover:bg-purple-200 transition-colors"
                          >
                            <Music className="w-4 h-4" />
                            <span>Dağıt</span>
                          </button>
                        )}
                      </div>
                    </div>

                    {song.status === 'rejected' && song.rejectionReason && (
                      <div className="mt-3 p-3 bg-red-50 border border-red-200 rounded-lg">
                        <p className="text-sm text-red-800">
                          <strong>Red Sebebi:</strong> {song.rejectionReason}
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Song Detail Modal */}
      {showSongModal && selectedSong && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 max-w-4xl w-full mx-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-semibold text-gray-900">Şarkı Detayları</h3>
              <button
                onClick={() => setShowSongModal(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-1">
                <img
                  src={selectedSong.albumCover}
                  alt={selectedSong.title}
                  className="w-full rounded-lg shadow-sm"
                />
              </div>

              <div className="lg:col-span-2 space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Şarkı Adı</label>
                    <p className="text-gray-900 font-semibold">{selectedSong.title}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Sanatçı</label>
                    <p className="text-gray-900">{selectedSong.artist}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Kullanıcı</label>
                    <p className="text-gray-900">{selectedSong.username}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Yayın Kodu</label>
                    <p className="text-gray-900 font-mono">{selectedSong.releaseCode}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Tür</label>
                    <p className="text-gray-900">{selectedSong.genre}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Yayın Türü</label>
                    <p className="text-gray-900 capitalize">{selectedSong.releaseType}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Dil</label>
                    <p className="text-gray-900">{selectedSong.language.toUpperCase()}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">ISRC Kodu</label>
                    <p className="text-gray-900">{selectedSong.isrcCode}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Durum</label>
                    <span className={`inline-flex items-center space-x-1 px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(selectedSong.status)}`}>
                      {getStatusIcon(selectedSong.status)}
                      <span>{getStatusText(selectedSong.status)}</span>
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Gönderim Tarihi</label>
                    <p className="text-gray-900">{new Date(selectedSong.submittedDate).toLocaleDateString('tr-TR')}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Yayın Tarihi</label>
                    <p className="text-gray-900">{new Date(selectedSong.releaseDate).toLocaleDateString('tr-TR')}</p>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Dosya Linki</label>
                  <a
                    href={selectedSong.fileLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-600 hover:text-blue-800 underline"
                  >
                    {selectedSong.fileLink}
                  </a>
                </div>

                {/* Primary Artists with Links */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-3">Birincil Sanatçılar</label>
                  <div className="space-y-3">
                    {selectedSong.primaryArtists.map((artist: any, index: number) => (
                      <div key={index} className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                        <div className="flex items-center justify-between">
                          <h4 className="font-medium text-blue-900">{artist.name}</h4>
                          <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full">Birincil</span>
                        </div>
                        <div className="mt-2 flex flex-wrap gap-2">
                          {artist.spotifyLink && (
                            <a
                              href={artist.spotifyLink}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center space-x-1 px-3 py-1 bg-green-100 text-green-800 rounded-lg hover:bg-green-200 transition-colors text-sm"
                            >
                              <ExternalLink className="w-3 h-3" />
                              <span>Spotify</span>
                            </a>
                          )}
                          {artist.appleMusicLink && (
                            <a
                              href={artist.appleMusicLink}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center space-x-1 px-3 py-1 bg-gray-100 text-gray-800 rounded-lg hover:bg-gray-200 transition-colors text-sm"
                            >
                              <ExternalLink className="w-3 h-3" />
                              <span>Apple Music</span>
                            </a>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Featured Artists with Links */}
                {selectedSong.featuredArtists.length > 0 && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-3">Düet Sanatçıları (ft.)</label>
                    <div className="space-y-3">
                      {selectedSong.featuredArtists.map((artist: any, index: number) => (
                        <div key={index} className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                          <div className="flex items-center justify-between">
                            <h4 className="font-medium text-purple-900">{artist.name}</h4>
                            <span className="text-xs bg-purple-100 text-purple-800 px-2 py-1 rounded-full">Düet</span>
                          </div>
                          <div className="mt-2 flex flex-wrap gap-2">
                            {artist.spotifyLink && (
                              <a
                                href={artist.spotifyLink}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="inline-flex items-center space-x-1 px-3 py-1 bg-green-100 text-green-800 rounded-lg hover:bg-green-200 transition-colors text-sm"
                              >
                                <ExternalLink className="w-3 h-3" />
                                <span>Spotify</span>
                              </a>
                            )}
                            {artist.appleMusicLink && (
                              <a
                                href={artist.appleMusicLink}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="inline-flex items-center space-x-1 px-3 py-1 bg-gray-100 text-gray-800 rounded-lg hover:bg-gray-200 transition-colors text-sm"
                              >
                                <ExternalLink className="w-3 h-3" />
                                <span>Apple Music</span>
                              </a>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <div className="flex items-center space-x-6">
                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-medium text-gray-700">Argo İçerik:</span>
                    <span className={`px-2 py-1 rounded-md text-sm ${selectedSong.hasExplicitContent ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'}`}>
                      {selectedSong.hasExplicitContent ? 'Var' : 'Yok'}
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-medium text-gray-700">YouTube Content ID:</span>
                    <span className={`px-2 py-1 rounded-md text-sm ${selectedSong.youtubeContentId ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'}`}>
                      {selectedSong.youtubeContentId ? 'Talep Edildi' : 'Talep Edilmedi'}
                    </span>
                  </div>
                </div>

                {selectedSong.status === 'rejected' && selectedSong.rejectionReason && (
                  <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                    <label className="block text-sm font-medium text-red-800 mb-2">Red Sebebi</label>
                    <p className="text-red-700">{selectedSong.rejectionReason}</p>
                  </div>
                )}

                {selectedSong.status === 'review' && (
                  <div className="flex flex-col space-y-4 pt-4 border-t border-gray-200">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Red Sebebi (Opsiyonel)
                      </label>
                      <textarea
                        value={rejectionReason}
                        onChange={(e) => setRejectionReason(e.target.value)}
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                        rows={3}
                        placeholder="Şarkıyı reddetme sebebinizi yazın..."
                      />
                    </div>
                    
                    <div className="flex space-x-4">
                      <button
                        onClick={() => handleSongAction('approve', selectedSong.id)}
                        className="flex-1 flex items-center justify-center space-x-2 px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                      >
                        <Check className="w-5 h-5" />
                        <span>Onayla</span>
                      </button>
                      <button
                        onClick={() => handleSongAction('reject', selectedSong.id, rejectionReason)}
                        className="flex-1 flex items-center justify-center space-x-2 px-6 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
                      >
                        <X className="w-5 h-5" />
                        <span>Reddet</span>
                      </button>
                    </div>
                  </div>
                )}

                {selectedSong.status === 'approved' && (
                  <div className="pt-4 border-t border-gray-200">
                    <button
                      onClick={() => handleSongAction('distribute', selectedSong.id)}
                      className="w-full flex items-center justify-center space-x-2 px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
                    >
                      <Music className="w-5 h-5" />
                      <span>Dağıtıma Başla</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminSongs;