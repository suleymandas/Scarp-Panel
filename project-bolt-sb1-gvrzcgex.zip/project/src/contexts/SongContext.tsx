import React, { createContext, useContext, useState, useEffect } from 'react';
import { generateReleaseCode } from '../types';
import { useNotifications } from './NotificationContext';

interface Song {
  id: string;
  releaseCode: string;
  title: string;
  artist: string;
  userId: string;
  username: string;
  albumCover: string;
  genre: string;
  releaseType: 'single' | 'ep' | 'album' | 'composition';
  submittedDate: string;
  releaseDate: string;
  status: 'review' | 'approved' | 'rejected' | 'distributed';
  fileLink: string;
  isrcCode: string;
  hasExplicitContent: boolean;
  youtubeContentId: boolean;
  language: string;
  rejectionReason?: string;
  primaryArtists: Array<{
    name: string;
    spotifyLink: string;
    appleMusicLink: string;
  }>;
  featuredArtists: Array<{
    name: string;
    spotifyLink: string;
    appleMusicLink: string;
  }>;
}

interface SongContextType {
  songs: Song[];
  addSong: (song: Omit<Song, 'id' | 'releaseCode' | 'submittedDate' | 'status'>) => void;
  updateSongStatus: (songId: string, status: Song['status'], rejectionReason?: string) => void;
  getSongsByUser: (userId: string) => Song[];
}

const SongContext = createContext<SongContextType | undefined>(undefined);

// Mock initial songs
const initialSongs: Song[] = [
  {
    id: '1',
    releaseCode: 'SCR202400001',
    title: 'Aşk Şarkısı',
    artist: 'Mehmet Yılmaz',
    userId: '1',
    username: 'artist1',
    albumCover: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=300',
    genre: 'Pop',
    releaseType: 'single',
    submittedDate: '2024-04-08',
    releaseDate: '2024-04-22',
    status: 'review',
    fileLink: 'https://wetransfer.com/downloads/example1',
    isrcCode: 'TR-ABC-24-00001',
    hasExplicitContent: false,
    youtubeContentId: true,
    language: 'tr',
    primaryArtists: [
      {
        name: 'Mehmet Yılmaz',
        spotifyLink: 'https://open.spotify.com/artist/mehmet-yilmaz',
        appleMusicLink: 'https://music.apple.com/artist/mehmet-yilmaz'
      }
    ],
    featuredArtists: []
  },
  {
    id: '2',
    releaseCode: 'SCR202400002',
    title: 'Yaz Gecesi',
    artist: 'Ayşe Demir',
    userId: '3',
    username: 'ayse_demir',
    albumCover: 'https://images.pexels.com/photos/1190297/pexels-photo-1190297.jpeg?auto=compress&cs=tinysrgb&w=300',
    genre: 'Pop',
    releaseType: 'single',
    submittedDate: '2024-04-07',
    releaseDate: '2024-04-21',
    status: 'approved',
    fileLink: 'https://wetransfer.com/downloads/example2',
    isrcCode: 'TR-ABC-24-00002',
    hasExplicitContent: false,
    youtubeContentId: false,
    language: 'tr',
    primaryArtists: [
      {
        name: 'Ayşe Demir',
        spotifyLink: 'https://open.spotify.com/artist/ayse-demir',
        appleMusicLink: 'https://music.apple.com/artist/ayse-demir'
      }
    ],
    featuredArtists: []
  },
  {
    id: '3',
    releaseCode: 'SCR202400003',
    title: 'Kış Masalı',
    artist: 'Ali Vural ft. Fatma Şahin',
    userId: '4',
    username: 'ali_vural',
    albumCover: 'https://images.pexels.com/photos/1763075/pexels-photo-1763075.jpeg?auto=compress&cs=tinysrgb&w=300',
    genre: 'Folk',
    releaseType: 'single',
    submittedDate: '2024-04-06',
    releaseDate: '2024-04-20',
    status: 'distributed',
    fileLink: 'https://wetransfer.com/downloads/example3',
    isrcCode: 'TR-ABC-24-00003',
    hasExplicitContent: false,
    youtubeContentId: true,
    language: 'tr',
    primaryArtists: [
      {
        name: 'Ali Vural',
        spotifyLink: 'https://open.spotify.com/artist/ali-vural',
        appleMusicLink: 'https://music.apple.com/artist/ali-vural'
      }
    ],
    featuredArtists: [
      {
        name: 'Fatma Şahin',
        spotifyLink: 'https://open.spotify.com/artist/fatma-sahin',
        appleMusicLink: 'https://music.apple.com/artist/fatma-sahin'
      }
    ]
  }
];

export const SongProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [songs, setSongs] = useState<Song[]>(() => {
    const savedSongs = localStorage.getItem('songs');
    return savedSongs ? JSON.parse(savedSongs) : initialSongs;
  });

  // Save to localStorage whenever songs change
  useEffect(() => {
    localStorage.setItem('songs', JSON.stringify(songs));
  }, [songs]);

  const addSong = (songData: Omit<Song, 'id' | 'releaseCode' | 'submittedDate' | 'status'>) => {
    const newSong: Song = {
      ...songData,
      id: Date.now().toString(),
      releaseCode: generateReleaseCode(),
      submittedDate: new Date().toISOString().split('T')[0],
      status: 'review'
    };

    setSongs(prevSongs => [...prevSongs, newSong]);
  };

  const updateSongStatus = (songId: string, status: Song['status'], rejectionReason?: string) => {
    setSongs(prevSongs => 
      prevSongs.map(song => 
        song.id === songId 
          ? { ...song, status, rejectionReason }
          : song
      )
    );
  };

  const getSongsByUser = (userId: string) => {
    return songs.filter(song => song.userId === userId);
  };

  return (
    <SongContext.Provider value={{ songs, addSong, updateSongStatus, getSongsByUser }}>
      {children}
    </SongContext.Provider>
  );
};

export const useSongs = () => {
  const context = useContext(SongContext);
  if (context === undefined) {
    throw new error('useSongs must be used within a SongProvider');
  }
  return context;
};