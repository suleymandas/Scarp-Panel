import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '../types';

interface AuthContextType {
  user: User | null;
  login: (username: string, password: string) => Promise<boolean>;
  logout: () => void;
  isLoading: boolean;
  addUser: (newUser: User, password: string) => void;
  getAllUsers: () => Array<User & { password: string }>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Default users
const defaultUsers: Array<User & { password: string }> = [
  {
    id: '1',
    username: 'artist1',
    password: '123456',
    role: 'artist',
    package: 'pro',
    artistCount: 2,
    totalSongs: 15,
    totalEarnings: 2450.50
  },
  {
    id: '2',
    username: 'admin',
    password: '123456',
    role: 'admin',
    package: 'unlimited',
    artistCount: 0,
    totalSongs: 0,
    totalEarnings: 0
  }
];

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [allUsers, setAllUsers] = useState<Array<User & { password: string }>>([]);

  // Initialize users from localStorage or use defaults
  useEffect(() => {
    const savedUsers = localStorage.getItem('allUsers');
    if (savedUsers) {
      try {
        const parsedUsers = JSON.parse(savedUsers);
        setAllUsers(parsedUsers);
      } catch (error) {
        console.error('Error parsing saved users:', error);
        setAllUsers(defaultUsers);
        localStorage.setItem('allUsers', JSON.stringify(defaultUsers));
      }
    } else {
      setAllUsers(defaultUsers);
      localStorage.setItem('allUsers', JSON.stringify(defaultUsers));
    }

    // Check for saved user session
    const savedUser = localStorage.getItem('currentUser');
    if (savedUser) {
      try {
        setUser(JSON.parse(savedUser));
      } catch (error) {
        console.error('Error parsing saved user:', error);
        localStorage.removeItem('currentUser');
      }
    }
    setIsLoading(false);
  }, []);

  // Save users to localStorage whenever allUsers changes
  useEffect(() => {
    if (allUsers.length > 0) {
      localStorage.setItem('allUsers', JSON.stringify(allUsers));
    }
  }, [allUsers]);

  const login = async (username: string, password: string): Promise<boolean> => {
    // Find user in current users list
    const foundUser = allUsers.find(u => u.username === username && u.password === password);
    if (foundUser) {
      const { password: _, ...userWithoutPassword } = foundUser;
      setUser(userWithoutPassword);
      localStorage.setItem('currentUser', JSON.stringify(userWithoutPassword));
      return true;
    }
    return false;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('currentUser');
  };

  const addUser = (newUser: User, password: string) => {
    const userWithPassword = {
      ...newUser,
      password
    };
    
    setAllUsers(prevUsers => {
      const updatedUsers = [...prevUsers, userWithPassword];
      localStorage.setItem('allUsers', JSON.stringify(updatedUsers));
      return updatedUsers;
    });
  };

  const getAllUsers = () => {
    return allUsers;
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, isLoading, addUser, getAllUsers }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};