import React, { createContext, useContext, useState, useEffect } from 'react';
import { useAuth } from './AuthContext';

export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'success' | 'warning' | 'info' | 'error';
  time: string;
  unread: boolean;
  relatedSongId?: string;
  relatedSongTitle?: string;
  actionType?: 'song_approved' | 'song_rejected' | 'song_distributed' | 'withdrawal_approved' | 'withdrawal_rejected' | 'general';
}

interface NotificationContextType {
  notifications: Notification[];
  unreadCount: number;
  addNotification: (notification: Omit<Notification, 'id' | 'time' | 'unread'>) => void;
  markAsRead: (notificationId: string) => void;
  markAllAsRead: (userId: string) => void;
  getNotificationsByUser: (userId: string) => Notification[];
  getUnreadCountByUser: (userId: string) => number;
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export const NotificationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState<Notification[]>(() => {
    const saved = localStorage.getItem('notifications');
    return saved ? JSON.parse(saved) : [];
  });

  // Save to localStorage whenever notifications change
  useEffect(() => {
    localStorage.setItem('notifications', JSON.stringify(notifications));
  }, [notifications]);

  const addNotification = (notificationData: Omit<Notification, 'id' | 'time' | 'unread'>) => {
    const newNotification: Notification = {
      ...notificationData,
      id: Date.now().toString(),
      time: new Date().toISOString(),
      unread: true
    };

    setNotifications(prev => [newNotification, ...prev]);
  };

  const markAsRead = (notificationId: string) => {
    setNotifications(prev => 
      prev.map(notification => 
        notification.id === notificationId 
          ? { ...notification, unread: false }
          : notification
      )
    );
  };

  const markAllAsRead = (userId: string) => {
    setNotifications(prev => 
      prev.map(notification => 
        notification.userId === userId 
          ? { ...notification, unread: false }
          : notification
      )
    );
  };

  const getNotificationsByUser = (userId: string) => {
    return notifications.filter(notification => notification.userId === userId);
  };

  const getUnreadCountByUser = (userId: string) => {
    return notifications.filter(notification => 
      notification.userId === userId && notification.unread
    ).length;
  };

  const unreadCount = user ? getUnreadCountByUser(user.id) : 0;

  return (
    <NotificationContext.Provider value={{
      notifications,
      unreadCount,
      addNotification,
      markAsRead,
      markAllAsRead,
      getNotificationsByUser,
      getUnreadCountByUser
    }}>
      {children}
    </NotificationContext.Provider>
  );
};

export const useNotifications = () => {
  const context = useContext(NotificationContext);
  if (context === undefined) {
    throw new Error('useNotifications must be used within a NotificationProvider');
  }
  return context;
};